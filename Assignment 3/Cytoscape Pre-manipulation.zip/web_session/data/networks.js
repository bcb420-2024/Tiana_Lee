var networks = {"Data Set 1": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Data Set 1",
    "name" : "Data Set 1",
    "SUID" : 176611,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "176918",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 1.0E-4,
        "EnrichmentMap_Name" : "METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6359,
        "EnrichmentMap_GS_DESCR" : "Metabotropic glutamate receptor group III pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 65,
        "EnrichmentMap_NES_Data_Set_1_" : 1.9637,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "VAMP1", "CACNA1A", "SNAP23", "GNAI3", "GRM1", "VAMP8", "GRM5", "ADCY10", "PRKAR1B", "VAMP3", "GRIA1", "SLC1A3", "SLC1A6", "SLC1A7", "GRIN2B", "SLC1A2", "GRIA3", "GRIA4", "STX1B", "GNG10", "VTI1A", "PRKAR1A", "GNG3", "SLC17A7", "GNG5", "VAMP2", "PRKAR2B", "GRIN1", "GNG4", "GNG7", "PRKAR2A", "GNG8", "CACNA1B", "GRM8", "GRIA2", "PRKX", "GRM4", "GRM7", "SLC1A1", "GRM6", "CACNB1", "GNAI2", "STX1A", "GNB2", "PRKACB", "GNB4", "CACNA1E", "GNB1", "GNGT2", "GNB5", "GRIN2C", "GRIN2D", "PRKACA", "GRIN3A", "GRIK5", "GRIK3", "GRIK4", "GRIK1", "GRIK2", "SNAP25", "GNAI1", "PRKACG", "GNB3", "GRIN2A", "SNAP29" ],
        "name" : "METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176918,
        "selected" : false
      },
      "position" : {
        "x" : -81.32067714160007,
        "y" : -438.7107889078841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176915",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8249,
        "EnrichmentMap_GS_DESCR" : "ATR signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 39,
        "EnrichmentMap_NES_Data_Set_1_" : 2.5183,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "CHEK1", "RFC5", "RPA2", "PLK1", "HUS1", "NBN", "YWHAB", "MCM7", "CDC25A", "TIMELESS", "CCNA2", "SMARCAL1", "CLSPN", "CEP164", "PPP2R2B", "YWHAZ", "FANCD2", "MCM2", "BRCA2", "FBXW11", "CDK2", "MDM2", "PPP2R1A", "RAD51", "TIPIN", "RAD9A", "RAD17", "ATRIP", "RPA1", "RFC3", "RFC2", "PPP2CA", "BTRC", "ATR", "CDC6", "TOPBP1", "CDC25C", "RAD1", "RFC4" ],
        "name" : "ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176915,
        "selected" : false
      },
      "position" : {
        "x" : -342.1212981743149,
        "y" : -424.7633096598372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176912",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.06,
        "EnrichmentMap_Name" : "INSULIN PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%INSULIN PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.465,
        "EnrichmentMap_GS_DESCR" : "Insulin Pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "INSULIN PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%INSULIN PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0167,
        "EnrichmentMap_gs_size" : 45,
        "EnrichmentMap_NES_Data_Set_1_" : -1.551,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9833,
        "EnrichmentMap_Genes" : [ "SOS1", "CAV1", "SHC1", "EIF4EBP1", "PARD6A", "RASA1", "PTPN1", "RPS6KB1", "RAPGEF1", "GRB14", "TRIP10", "GRB10", "PTPN11", "INPP5D", "DOK1", "EXOC7", "CRK", "EXOC3", "EXOC2", "PRKCZ", "GRB2", "NCK2", "PRKCI", "AKT2", "F2RL2", "EXOC6", "NCK1", "AKT1", "EXOC5", "INSR", "EXOC1", "PTPRA", "FOXO3", "IRS1", "PIK3CA", "INS", "RHOQ", "SGK1", "PDPK1", "PIK3R1", "HRAS", "SH2B2", "CBL", "SORBS1", "EXOC4" ],
        "name" : "INSULIN PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%INSULIN PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176912,
        "selected" : false
      },
      "position" : {
        "x" : -415.32596049731296,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176909",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0029,
        "EnrichmentMap_Name" : "ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7761,
        "EnrichmentMap_GS_DESCR" : "Endogenous_cannabinoid_signaling",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730",
        "EnrichmentMap_pvalue_Data_Set_1_" : 6.0E-4,
        "EnrichmentMap_gs_size" : 23,
        "EnrichmentMap_NES_Data_Set_1_" : 1.8907,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9994,
        "EnrichmentMap_Genes" : [ "PLCB2", "CACNA1G", "CACNA1A", "GNG11", "GNG3", "GNAI3", "GNG5", "GNAO1", "GRM1", "GNG4", "GNAI1", "GRM5", "GNG7", "GNG8", "PLCB3", "GNB2", "GNB4", "CACNA1B", "GNB3", "PLCB1", "GNB1", "GNGT2", "CNR1" ],
        "name" : "ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176909,
        "selected" : false
      },
      "position" : {
        "x" : 18.489775796479762,
        "y" : -491.4293252848372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176906",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0448,
        "EnrichmentMap_Name" : "BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.6325,
        "EnrichmentMap_GS_DESCR" : "BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0118,
        "EnrichmentMap_gs_size" : 18,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7086,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9882,
        "EnrichmentMap_Genes" : [ "GRB2", "SOS1", "IL6ST", "SHC1", "IL6R", "CSNK2A1", "FOS", "JUN", "JAK3", "MAP2K1", "STAT3", "PTPN11", "JAK1", "RAF1", "IL6", "HRAS", "MAPK3", "CEBPB" ],
        "name" : "BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176906,
        "selected" : false
      },
      "position" : {
        "x" : 452.4204522567459,
        "y" : -427.4071847819075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176903",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0596,
        "EnrichmentMap_Name" : "E-CADHERIN SIGNALING IN KERATINOCYTES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E-CADHERIN SIGNALING IN KERATINOCYTES",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5844,
        "EnrichmentMap_GS_DESCR" : "E-cadherin signaling in keratinocytes",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "E-CADHERIN SIGNALING IN KERATINOCYTES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E-CADHERIN SIGNALING IN KERATINOCYTES",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0165,
        "EnrichmentMap_gs_size" : 21,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6338,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9835,
        "EnrichmentMap_Genes" : [ "AKT2", "RAC1", "SRC", "AKT1", "EGFR", "CTNNA1", "AJUBA", "PIK3CA", "FYN", "ZYX", "PIK3R1", "CDH1", "CTNND1", "PIP5K1A", "CASR", "FMN1", "VASP", "PLCG1", "CTNNB1", "RHOA", "JUP" ],
        "name" : "E-CADHERIN SIGNALING IN KERATINOCYTES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E-CADHERIN SIGNALING IN KERATINOCYTES",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176903,
        "selected" : false
      },
      "position" : {
        "x" : -313.004370073729,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176900",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0227,
        "EnrichmentMap_Name" : "TNFALPHA%IOB%TNFALPHA",
        "EnrichmentMap_ES_Data_Set_1_" : 0.388,
        "EnrichmentMap_GS_DESCR" : "TNFalpha",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "TNFALPHA%IOB%TNFALPHA",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0053,
        "EnrichmentMap_gs_size" : 168,
        "EnrichmentMap_NES_Data_Set_1_" : 1.4703,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9947,
        "EnrichmentMap_Genes" : [ "RB1", "KPNA2", "SMARCC1", "MAP2K5", "G3BP2", "RPL30", "FLNA", "FBXW7", "MAP3K1", "LRPPRC", "TNFRSF8", "PRC1", "TRIB3", "TRAF3", "NUPR1", "HEL2", "MAPKAPK2", "FADD", "UBE2I", "PKN1", "FAF1", "NFKBIZ", "CSNK2A1", "TNFRSF1B", "JUN", "KIAA0287", "YWHAZ", "IKBKB", "TBK1", "CASP10", "HEL-S-1", "TNF", "CDC37", "MAP3K7", "BRINP1", "TRAF2", "COPB2", "MTIF2", "IKBKAP", "IKBKG", "TNFRSF1A", "HDAC1", "MAP3K8", "PSMD12", "SYK", "PSMD13", "CREBBP", "NR2C2", "MAPK3", "SRC", "COPS5", "POLR1C", "CDK9", "CASP8", "POLR1D", "EGFR", "CASP3", "MAPK9", "CASP2", "MAPK8", "MAP3K7IP1", "HEL-S-102", "NFKB1", "MAPK1", "UBE2D2", "RIPK1", "NFKB2", "TRAF4", "RPS6KB1", "NFKBIA", "MAP2K6", "STAT1", "PTPN11", "REL", "POLR2H", "NFKBIE", "DOK1", "CREB1", "PRKCZ", "DKFZP686J04131", "NFKBIB", "SUMO1", "RPL6", "GLG1", "FBL", "BAG4", "RELA", "PSMD7", "CRADD", "SEC16A", "MCC", "UBE2D3", "SMARCA4", "PSMD3", "ALPL", "PSMD1", "TAB3", "TRADD", "TRAF1", "PPP6C", "BCL7A", "PPP1R13L", "NKIRAS2", "IKBKE", "BIRC2", "RIPK3", "ACTL6A", "COMMD1", "RASA3", "NKIRAS1", "MUXA", "POLR1A", "TRAF6", "TANK", "YWHAG", "TRAF5", "PFDN2", "RELB", "FKBP5", "AKAP8", "TIFA", "CHUK", "POLR2L", "MAP3K2", "SMARCE1", "RNF25", "KTN1", "PSMC1", "PDCD2", "TBKBP1", "RPL4", "ZFAND5", "RPL8", "DKFZP566E044", "DCAF7", "MCM7", "PSMD6", "TNIP2", "PSMD2", "DKFZP781N011", "PAPOLA", "TNFAIP3", "KPNA6", "HSP90AB1", "DPF2", "RPS11", "YWHAQ", "AZI2", "KPNA3", "RPS13", "MAP3K11", "GTF2I", "SMARCC2", "USP2", "TRPC4AP", "MCM5", "TXLNA", "SKP1", "FANCD2", "NSMAF", "TNFRSF11A", "FBXW11", "HDAC2", "DDX3X", "MAPK14", "PML", "CDC34", "RPS6KA5" ],
        "name" : "TNFALPHA%IOB%TNFALPHA",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176900,
        "selected" : false
      },
      "position" : {
        "x" : -210.682779650145,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176897",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0032,
        "EnrichmentMap_Name" : "REGULATION OF TELOMERASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%REGULATION OF TELOMERASE",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5435,
        "EnrichmentMap_GS_DESCR" : "Regulation of Telomerase",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "REGULATION OF TELOMERASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%REGULATION OF TELOMERASE",
        "EnrichmentMap_pvalue_Data_Set_1_" : 6.0E-4,
        "EnrichmentMap_gs_size" : 69,
        "EnrichmentMap_NES_Data_Set_1_" : 1.7793,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9994,
        "EnrichmentMap_Genes" : [ "RBBP4", "FOS", "EGFR", "HUS1", "PINX1", "SMG6", "NFKB1", "MAPK1", "TINF2", "SMG5", "POT1", "TERF2IP", "RPS6KB1", "ACD", "DKC1", "NCL", "ZNFX1", "IRF1", "ABL1", "RBBP7", "TERF2", "E2F1", "HSP90AA1", "SIN3B", "BLM", "TNKS", "TERF1", "CDKN1B", "IFNAR2", "MAX", "RAD50", "RAD1", "XRCC5", "PARP2", "MRE11", "XRCC6", "NBN", "YWHAE", "HNRNPC", "JUN", "IL2", "TGFB1", "SAP18", "PTGES3", "PIF1", "MTOR", "ATM", "SAP30", "IFNG", "SP1", "WRN", "HDAC2", "CCND1", "AKT1", "MXD1", "NR2F2", "RAD9A", "MYC", "SMAD3", "SIN3A", "EGF", "ESR1", "HDAC1", "E6", "UBE3A", "SP3", "WT1", "MAPK3", "TERT" ],
        "name" : "REGULATION OF TELOMERASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%REGULATION OF TELOMERASE",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176897,
        "selected" : false
      },
      "position" : {
        "x" : -118.76603923266453,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176894",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0058,
        "EnrichmentMap_Name" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY%MSIGDB_C2%PID_ECADHERIN_KERATINOCYTE_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.7304,
        "EnrichmentMap_GS_DESCR" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY%MSIGDB_C2%PID_ECADHERIN_KERATINOCYTE_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0012,
        "EnrichmentMap_gs_size" : 17,
        "EnrichmentMap_NES_Data_Set_1_" : -1.8952,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9988,
        "EnrichmentMap_Genes" : [ "SRC", "DKFZP434N101", "RAC1", "EGFR", "ARHA", "CTNNA1", "AJUBA", "FYN", "ZYX", "PIK3R1", "PIP5K1A", "CASR", "CTNND1", "FMN1", "CTNNB1", "VASP", "JUP" ],
        "name" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY%MSIGDB_C2%PID_ECADHERIN_KERATINOCYTE_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176894,
        "selected" : false
      },
      "position" : {
        "x" : -310.682779650145,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176891",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 4.0E-4,
        "EnrichmentMap_Name" : "ATM PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATM PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6866,
        "EnrichmentMap_GS_DESCR" : "ATM pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ATM PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATM PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 1.0E-4,
        "EnrichmentMap_gs_size" : 34,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0172,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9999,
        "EnrichmentMap_Genes" : [ "BRCA1", "RBBP8", "MRE11", "CHEK2", "NBN", "YWHAB", "CDC25A", "COP1", "UBE2N", "FANCD2", "KAT5", "MDC1", "ABL1", "ATM", "ABRAXAS1", "RNF8", "MDM2", "UIMC1", "TP53BP1", "TERF2", "BLM", "RAD9A", "RAD17", "TRIM28", "SMC1A", "TOP3A", "CTBP1", "BID", "SMC3", "RAD50", "DCLRE1C", "CDC25C", "XRCC4", "H2AX" ],
        "name" : "ATM PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATM PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176891,
        "selected" : false
      },
      "position" : {
        "x" : -108.36118922656101,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176888",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_FOXM1_PATHWAY%MSIGDB_C2%PID_FOXM1_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7511,
        "EnrichmentMap_GS_DESCR" : "PID_FOXM1_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_FOXM1_PATHWAY%MSIGDB_C2%PID_FOXM1_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 38,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2084,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "RB1", "CKS1B", "PLK1", "FOS", "ONECUT1", "DKFZP686G14213", "CHEK2", "CENPA", "LAMA4", "CCNE1", "CDC2", "CCNB1", "CCNA2", "MAP2K1", "FOXM1", "CENPB", "H2BC1", "NFATC3", "BRCA2", "CDK4", "CDK2", "AURKB", "EP300", "SP1", "MMP2", "CCND1", "CENPF", "GSK3A", "CDKN2A", "MYC", "SKP2", "GAS1", "ETV5", "CREBBP", "CCNB2", "TGFA", "NEK2", "BIRC5" ],
        "name" : "PID_FOXM1_PATHWAY%MSIGDB_C2%PID_FOXM1_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176888,
        "selected" : false
      },
      "position" : {
        "x" : -6.039598802977025,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176885",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0131,
        "EnrichmentMap_Name" : "PDGF SIGNALING PATHWAY%PANTHER PATHWAY%P00047",
        "EnrichmentMap_ES_Data_Set_1_" : -0.3853,
        "EnrichmentMap_GS_DESCR" : "PDGF signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PDGF SIGNALING PATHWAY%PANTHER PATHWAY%P00047",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0028,
        "EnrichmentMap_gs_size" : 125,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5419,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9972,
        "EnrichmentMap_Genes" : [ "SOS1", "ARHGAP1", "RASA4B", "GAB1", "ARHGAP26", "RASA1", "ARHGAP9", "PIK3CD", "ETS1", "ARHGAP42", "SHC3", "VAV2", "STAT6", "RPS6KA4", "BRAF", "PDGFRB", "PDGFB", "MAPK6", "RPS6KB2", "SHC2", "MAPKAPK2", "OPHN1", "PDGFA", "PIK3R5", "ITPR1", "SHC1", "ARHGAP8", "SRGAP1", "JUN", "MAPK15", "IKBKB", "SPDEF", "RPS6KA3", "RPS6KA1", "VAV3", "ELF4", "NRAS", "ITPR3", "MYCBP", "GRAP", "GRAP2", "USF2", "RAF1", "ARHGAP6", "HRAS", "SRF", "MAPK3", "PIK3R3", "ITPR2", "MAPK7", "RPS6KA6", "FOS", "MAPK8", "ELK1", "MAPK1", "ELF2", "RPS6KB1", "RASA4", "STAT1", "JAK3", "MAP2K1", "STAT5B", "STAT2", "STAT3", "MKNK2", "MAP2K2", "MAPK10", "VAV1", "PDGFRA", "GRB2", "AKT2", "MAP3K4", "GSK3B", "ETV3", "RPS6KA2", "ELF3", "JAK1", "CHUK", "MAP3K2", "PKN2", "ELK4", "MKNK1", "NINL", "ELF1", "ARHGAP5", "ARHGAP4", "PIK3CB", "PIK3CG", "NCK2", "EHF", "PDGFRL", "ERF", "NCK1", "ERG", "ARHGAP15", "ARHGAP12", "SRGAP3", "FLI1", "GSK3A", "FEV", "MYC", "RERG", "GABPA", "GAB2", "STAT4", "ELF5", "ARAF", "PIK3CA", "RPS6KC1", "PIK3C3", "ELP1", "RAB11B", "NIN", "ARHGAP10", "JAK2", "PDPK1", "PIK3R2", "STAT5A", "PIK3R1", "PLCG2", "RASA2", "PRKCA", "PLCG1", "SOS2", "RPS6KA5" ],
        "name" : "PDGF SIGNALING PATHWAY%PANTHER PATHWAY%P00047",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176885,
        "selected" : false
      },
      "position" : {
        "x" : 462.5397759872146,
        "y" : -536.3361246012435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176882",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0028,
        "EnrichmentMap_Name" : "BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS",
        "EnrichmentMap_ES_Data_Set_1_" : -0.515,
        "EnrichmentMap_GS_DESCR" : "Beta1 integrin cell surface interactions",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS",
        "EnrichmentMap_pvalue_Data_Set_1_" : 5.0E-4,
        "EnrichmentMap_gs_size" : 66,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7829,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9995,
        "EnrichmentMap_Genes" : [ "CD81", "VEGFA", "FN1", "COL6A3", "COL11A1", "COL3A1", "COL5A1", "COL6A2", "COL7A1", "COL2A1", "COL18A1", "COL4A4", "COL4A3", "COL4A6", "COL4A5", "IGSF8", "ITGA10", "ITGA11", "VCAM1", "ITGA8", "ITGA4", "ITGA7", "ITGA5", "ITGA9", "TNC", "COL1A1", "TGM2", "COL4A1", "COL1A2", "COL5A2", "LAMB3", "TGFBI", "FBN1", "F13A1", "ITGB1", "LAMA4", "COL6A1", "LAMC2", "LAMA5", "LAMC1", "ITGA6", "JAM2", "LAMB2", "LAMB1", "ITGAV", "NPNT", "NID1", "CSPG4", "COL11A2", "ITGA1", "ITGA2", "PLAUR", "FGG", "MDK", "FGB", "FGA", "VTN", "LAMA1", "ITGA3", "LAMA3", "THBS2", "CD14", "THBS1", "PLAU", "SPP1", "LAMA2" ],
        "name" : "BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176882,
        "selected" : false
      },
      "position" : {
        "x" : 661.7384759383865,
        "y" : -494.1477014445052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176879",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0208,
        "EnrichmentMap_Name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4704,
        "EnrichmentMap_GS_DESCR" : "Validated targets of C-MYC transcriptional repression",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0048,
        "EnrichmentMap_gs_size" : 63,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6363,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9952,
        "EnrichmentMap_Genes" : [ "BRCA1", "TBP", "CCL5", "CEBPA", "SMAD2", "HDAC3", "NFYC", "LGALS1", "CREB1", "DDIT3", "PDGFRB", "CDKN1B", "CDKN2B", "ERBB2", "DNMT3A", "NDRG1", "ZFP36L1", "TJP2", "SPI1", "MAX", "DKK1", "DNTT", "SFRP1", "CEBPD", "HMGCS2", "COL1A2", "SMAD4", "ID2", "ALDH9A1", "FTH1", "ITGB1", "SLC11A1", "TMEFF2", "ITGA6", "CSDE1", "TMEM126A", "GADD45A", "S100A7", "GTF2H2", "WNT5A", "RBL1", "SFXN3", "BCL2", "EP300", "IRF8", "SP1", "PTPA", "CLU", "CCND1", "MXD4", "NFYA", "NFYB", "CDKN1A", "FOXO3", "MYC", "TSC2", "ZBTB17", "ITGB4", "SMAD3", "NDRG2", "CFLAR", "HDAC1", "GFI1" ],
        "name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL REPRESSION",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176879,
        "selected" : false
      },
      "position" : {
        "x" : -18.766039232664525,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176876",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_PLK1_PATHWAY%MSIGDB_C2%PID_PLK1_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7726,
        "EnrichmentMap_GS_DESCR" : "PID_PLK1_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_PLK1_PATHWAY%MSIGDB_C2%PID_PLK1_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 40,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2092,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "ECT2", "KNTC2", "BUB1B", "PLK1", "DKFZP686G14213", "ARHA", "FZR1", "CDC2", "RAB1A", "AURKA", "CCNB1", "ERCC6L", "SETCTP", "GOLGA2", "HEL-S-80P", "CLSPN", "SGOL1", "NINL", "NUDC", "CENPU", "C13ORF34", "GORASP1", "ROCK2", "KIZ", "DKFZP686I05169", "FBXW11", "PPP2R1A", "KIF20A", "CENPE", "CDC14B", "PAK1", "PRC1", "PPP2CA", "WEE1", "TUBG1", "INCENP", "HCTP4", "CDC20", "FBXO5", "SPC24" ],
        "name" : "PID_PLK1_PATHWAY%MSIGDB_C2%PID_PLK1_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176876,
        "selected" : false
      },
      "position" : {
        "x" : 96.28199162060696,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176873",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0938,
        "EnrichmentMap_Name" : "PID_RHOA_REG_PATHWAY%MSIGDB_C2%PID_RHOA_REG_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4918,
        "EnrichmentMap_GS_DESCR" : "PID_RHOA_REG_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_RHOA_REG_PATHWAY%MSIGDB_C2%PID_RHOA_REG_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0277,
        "EnrichmentMap_gs_size" : 38,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5461,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9723,
        "EnrichmentMap_Genes" : [ "ECT2", "ARHGDIB", "ARHGDIG", "ARHGAP8", "ARHA", "ARHGEF25", "ARHGEF28", "ARHGAP35", "ARHGEF10L", "MCF2L", "SRGAP1", "BCR", "ARHGEF10", "NET1", "HEL-S-47E", "ARHGEF15", "ARHGEF17", "PLEKHG6", "ARHGEF18", "OBSCN", "VAV1", "ARHGAP5", "ARHGAP4", "ARHGEF1", "FARP1", "VAV2", "MYO9B", "ARHGEF11", "ARHGEF12", "VAV3", "CDKN1B", "TRIO", "DEF6", "ARAP1", "OPHN1", "ARHGEF3", "ARHGEF5", "ARHGEF2" ],
        "name" : "PID_RHOA_REG_PATHWAY%MSIGDB_C2%PID_RHOA_REG_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176873,
        "selected" : false
      },
      "position" : {
        "x" : 81.23396076733547,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176870",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0017,
        "EnrichmentMap_Name" : "PID_INTEGRIN1_PATHWAY%MSIGDB_C2%PID_INTEGRIN1_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5782,
        "EnrichmentMap_GS_DESCR" : "PID_INTEGRIN1_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_INTEGRIN1_PATHWAY%MSIGDB_C2%PID_INTEGRIN1_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 3.0E-4,
        "EnrichmentMap_gs_size" : 49,
        "EnrichmentMap_NES_Data_Set_1_" : -1.9065,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9997,
        "EnrichmentMap_Genes" : [ "CD81", "HEL-S-45", "VEGFA", "COL3A1", "COL2A1", "COL18A1", "COL4A4", "COL4A3", "COL4A6", "COL4A5", "IGSF8", "VCAM1", "ITGA4", "COL1A1", "COL4A1", "COL1A2", "COL5A2", "TGFBI", "LAMB3", "FBN1", "F13A1", "ITGB1", "LAMA4", "COL6A1", "LAMA5", "LAMC2", "ITGA6", "LAMC1", "JAM2", "LAMB2", "LAMB1", "NPNT", "ITGAV", "NID1", "CSPG4", "COL11A2", "ITGA1", "ITGA2", "PLAUR", "HEL-S-78P", "MDK", "FGA", "VTN", "LAMA1", "LAMA3", "THBS2", "CD14", "THBS1", "SPP1" ],
        "name" : "PID_INTEGRIN1_PATHWAY%MSIGDB_C2%PID_INTEGRIN1_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176870,
        "selected" : false
      },
      "position" : {
        "x" : 756.2157708602615,
        "y" : -440.517715635179
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176867",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0024,
        "EnrichmentMap_Name" : "INTEGRIN SIGNALLING PATHWAY%PANTHER PATHWAY%P00034",
        "EnrichmentMap_ES_Data_Set_1_" : -0.3914,
        "EnrichmentMap_GS_DESCR" : "Integrin signalling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "INTEGRIN SIGNALLING PATHWAY%PANTHER PATHWAY%P00034",
        "EnrichmentMap_pvalue_Data_Set_1_" : 4.0E-4,
        "EnrichmentMap_gs_size" : 164,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5952,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9996,
        "EnrichmentMap_Genes" : [ "SOS1", "ASAP1", "BCAR1", "CAV1", "ARF6", "ARHGAP26", "PTK2", "COL6A3", "COL11A1", "COL3A1", "CDC42", "COL5A1", "COL6A2", "PIK3CD", "COL16A1", "FLNA", "FLNB", "COL12A1", "BRAF", "ITGB6", "TLN1", "MAPK6", "ITGB2", "ITGAL", "ITGAD", "ACTN2", "ITGA10", "ITGA11", "ITGA8", "ITGA4", "ITGA7", "ITGA5", "ITGA2B", "ITGA9", "MAP3K3", "COL4A2", "PTK2B", "COL4A1", "COL8A2", "ITGB8", "ITGAE", "MAP3K5", "SHC1", "ACTN1", "ACTN4", "RAP1A", "COL6A1", "RAPGEF1", "LAMA5", "ITGA6", "COL17A1", "DNAJC27", "ITGAM", "LAMB2", "LAMB1", "PXN", "RRAS", "PARVB", "ARPC5L", "RHOC", "LIMS1", "ITGA1", "VASP", "ACTB", "PARVA", "MAP2K4", "RAC1", "ARPC2", "ACTBL2", "MAP2K3", "COL9A1", "ITGAX", "NRAS", "RAP1B", "ITGB4", "NTN4", "CSK", "RAF1", "HRAS", "MAPK3", "PIK3R3", "SRC", "COL20A1", "VCL", "RAP2C", "RAP2A", "COL15A1", "MAPK9", "LAMB4", "MAPK8", "PTPN12", "FN1", "DMBT1", "RAP2B", "COL27A1", "ARL1", "ITGBL1", "RAC2", "FYN", "LAMC3", "MAPK13", "RND2", "RND3", "MAP2K1", "RND1", "COL2A1", "CRKL", "MAPK10", "MAP2K2", "CRK", "ARPC3", "MAP3K4", "COL4A4", "COL4A3", "COL4A6", "COL4A5", "ARF1", "COL1A1", "COL1A2", "COL5A3", "MAP3K2", "COL5A2", "LAMB3", "ITGB1", "LAMA4", "ITGB5", "LAMC1", "ITGB7", "COL14A1", "COL10A1", "ITGAV", "COL8A1", "COL13A1", "COL11A2", "ELMO2", "COL9A3", "COL9A2", "LIMS2", "PIK3CB", "ITGA2", "PIK3C2A", "PIK3CG", "ARPC1A", "PIK3C2B", "ACTG1", "ELMO1", "RHOB", "ARFGAP1", "PIK3CA", "ARAF", "PIK3C3", "ARHGAP10", "LAMA1", "PIK3R2", "ITGA3", "LAMA3", "PIK3R1", "ARPC5", "ARPC1B", "DOCK1", "ILK", "SOS2", "RHOA", "LAMA2" ],
        "name" : "INTEGRIN SIGNALLING PATHWAY%PANTHER PATHWAY%P00034",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176867,
        "selected" : false
      },
      "position" : {
        "x" : 562.5397759872146,
        "y" : -536.3361246012435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176864",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "E2F TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E2F TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_ES_Data_Set_1_" : 0.659,
        "EnrichmentMap_GS_DESCR" : "E2F transcription factor network",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "E2F TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E2F TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 74,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2058,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "RB1", "HIC1", "CCNE2", "DHFR", "CES3", "BRCA1", "RBBP8", "RBBP4", "E2F7", "RYBP", "CASP7", "TRRAP", "SULT2A1", "CDC25A", "TYMS", "CCND3", "CEBPA", "PRMT5", "E2F5", "SERPINE1", "WASF1", "CDK2", "E2F1", "RANBP1", "RRM2", "CDKN1B", "TRIM28", "CDKN2A", "UXT", "CDC6", "TOPBP1", "SIRT1", "CDK1", "MYBL2", "CCNE1", "HBP1", "CCNA2", "TFDP1", "RBL1", "CBX5", "TP73", "CES5A", "CES4A", "RBL2", "EP300", "ATM", "CES2", "SP1", "SMARCA2", "E2F2", "E2F3", "TFE3", "E2F4", "POLA1", "CDKN1A", "CES1", "MYC", "RRM1", "XRCC1", "KAT2B", "TK1", "CDKN2C", "TFDP2", "MCM3", "CES1P1", "ORC1", "HDAC1", "E2F6", "YY1", "MCL1", "KAT2A", "CREBBP", "PLAU", "APAF1" ],
        "name" : "E2F TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E2F TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176864,
        "selected" : false
      },
      "position" : {
        "x" : 198.60358204419094,
        "y" : 18.564775285841506
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176861",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 7.0E-4,
        "EnrichmentMap_Name" : "PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5793,
        "EnrichmentMap_GS_DESCR" : "PID_FAK_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 1.0E-4,
        "EnrichmentMap_gs_size" : 52,
        "EnrichmentMap_NES_Data_Set_1_" : -1.9658,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9999,
        "EnrichmentMap_Genes" : [ "ASAP1", "SOS1", "SRC", "SH3GL1", "ARHA", "ARHGAP26", "MAPK9", "KLF8", "MAPK8", "MAPK1", "FYN", "PTPN21", "MAP2K1", "CRK", "GRB2", "DKFZP434N101", "BRAF", "PAK1", "TLN1", "KIAA0142", "DKFZP666O0110", "HEL114", "BMX", "GIT2", "ITGB1", "ACTN1", "ARHGEF28", "ARHGAP35", "ITGB5", "RAP1A", "RAPGEF1", "JUN", "GRB7", "YES1", "PXN", "RRAS", "ROCK2", "WASL", "ITGAV", "MAPK8IP3", "NCK2", "MAP2K4", "RAC1", "CCND1", "NCK1", "ELMO1", "ARHGEF11", "MMP14", "PIK3R1", "RAF1", "ACTA1", "DOCK1" ],
        "name" : "PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176861,
        "selected" : false
      },
      "position" : {
        "x" : -525.4452842277817,
        "y" : 19.771547136427444
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176858",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0662,
        "EnrichmentMap_Name" : "DE NOVO PURINE BIOSYNTHESIS%PANTHER PATHWAY%P02738",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5797,
        "EnrichmentMap_GS_DESCR" : "De novo purine biosynthesis",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "DE NOVO PURINE BIOSYNTHESIS%PANTHER PATHWAY%P02738",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0186,
        "EnrichmentMap_gs_size" : 26,
        "EnrichmentMap_NES_Data_Set_1_" : 1.6348,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9814,
        "EnrichmentMap_Genes" : [ "ADSL", "RRM2B", "AK2", "NME2", "NME5", "NME1", "NME6", "NME7", "RRM2", "RRM1", "AK8", "ATIC", "GUK1", "AK3", "PPAT", "AK4", "DSCAML1", "IMPDH2", "ADSS1", "ADSS2", "GART", "AK1", "GMPS", "AK5", "NME3", "NME4" ],
        "name" : "DE NOVO PURINE BIOSYNTHESIS%PANTHER PATHWAY%P02738",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176858,
        "selected" : false
      },
      "position" : {
        "x" : 181.23396076733547,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176855",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "DNA REPLICATION%PANTHER PATHWAY%P00017",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8998,
        "EnrichmentMap_GS_DESCR" : "DNA replication",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "DNA REPLICATION%PANTHER PATHWAY%P00017",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 17,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2309,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "RFC5", "RPA2", "H3-4", "RFC1", "POLA1", "PRIM1", "TOP1", "RFC3", "RFC2", "PCNA", "TOP2A", "DNA2", "TOP2B", "H3-5", "POLD1", "RFC4", "POLD2" ],
        "name" : "DNA REPLICATION%PANTHER PATHWAY%P00017",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176855,
        "selected" : false
      },
      "position" : {
        "x" : 281.2339607673355,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176852",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.9037,
        "EnrichmentMap_GS_DESCR" : "PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 20,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2908,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "PDE6G", "SLC24A1", "GUCY2D", "CNGA1", "GNAT1", "DKFZP686E1183", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "RGS9BP", "RDH12", "SAG", "RDH5", "RHO", "LRAT", "PDE6A", "GNB1", "GNGT1", "GNB5" ],
        "name" : "PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176852,
        "selected" : false
      },
      "position" : {
        "x" : 349.1174737411209,
        "y" : -497.28676241862627
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176849",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0118,
        "EnrichmentMap_Name" : "BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7114,
        "EnrichmentMap_GS_DESCR" : "BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0025,
        "EnrichmentMap_gs_size" : 21,
        "EnrichmentMap_NES_Data_Set_1_" : 1.8034,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9975,
        "EnrichmentMap_Genes" : [ "CHEK1", "BRCA1", "RAD51", "HUS1", "CHEK2", "NBN", "RAD17", "RAD9A", "FANCA", "MRE11A", "FANCE", "FANCG", "TREX1", "FANCF", "RAD50", "FANCC", "ATR", "FANCD2", "BRCA2", "RAD1", "ATM" ],
        "name" : "BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176849,
        "selected" : false
      },
      "position" : {
        "x" : -418.7169478935532,
        "y" : -189.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176846",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0855,
        "EnrichmentMap_Name" : "PID_REELIN_PATHWAY%MSIGDB_C2%PID_REELIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5776,
        "EnrichmentMap_GS_DESCR" : "PID_REELIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_REELIN_PATHWAY%MSIGDB_C2%PID_REELIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.025,
        "EnrichmentMap_gs_size" : 22,
        "EnrichmentMap_NES_Data_Set_1_" : -1.633,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.975,
        "EnrichmentMap_Genes" : [ "DAB1", "NCK2", "RELN", "PAFAH1B1", "GSK3B", "LRPAP1", "CDK5", "ITGB1", "MAPK8", "RAP1A", "RAPGEF1", "FYN", "MAP3K11", "CRKL", "PIK3R1", "CDK5R1", "VLDLR", "CBL", "LRP8", "MAP1B", "GRIN2B", "ARHGEF2" ],
        "name" : "PID_REELIN_PATHWAY%MSIGDB_C2%PID_REELIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176846,
        "selected" : false
      },
      "position" : {
        "x" : 381.2339607673355,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176843",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0171,
        "EnrichmentMap_Name" : "PARKINSON DISEASE%PANTHER PATHWAY%P00049",
        "EnrichmentMap_ES_Data_Set_1_" : 0.4715,
        "EnrichmentMap_GS_DESCR" : "Parkinson disease",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PARKINSON DISEASE%PANTHER PATHWAY%P00049",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0038,
        "EnrichmentMap_gs_size" : 47,
        "EnrichmentMap_NES_Data_Set_1_" : 1.6044,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9962,
        "EnrichmentMap_Genes" : [ "SLC6A3", "MAPK12", "CCNE2", "MAPK7", "NDUFV2", "CASK", "SFN", "MAPK9", "YWHAE", "PSMA4", "YWHAB", "MAPK8", "CCNE1", "ELK1", "MAPK1", "YWHAH", "STX7", "MAPK15", "YWHAQ", "SEPTIN4", "SEPTIN1", "MAPK10", "YWHAZ", "PSMA3", "SEPTIN5", "GPR37L1", "PSMA5", "PSMA2", "PSMA6", "STX12", "GPR37", "PSMA1", "PSMA7", "PSMA8", "SNCAIP", "PSMB7", "PSMB1", "PSMB3", "PLD2", "SEPTIN2", "PSMB10", "TH", "MAPK14", "PRKN", "YWHAG", "MAPK3", "SNCA" ],
        "name" : "PARKINSON DISEASE%PANTHER PATHWAY%P00049",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176843,
        "selected" : false
      },
      "position" : {
        "x" : 481.2339607673355,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176840",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0438,
        "EnrichmentMap_Name" : "TRANSCRIPTION REGULATION BY BZIP TRANSCRIPTION FACTOR%PANTHER PATHWAY%P00055",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5152,
        "EnrichmentMap_GS_DESCR" : "Transcription regulation by bZIP transcription factor",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "TRANSCRIPTION REGULATION BY BZIP TRANSCRIPTION FACTOR%PANTHER PATHWAY%P00055",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0114,
        "EnrichmentMap_gs_size" : 47,
        "EnrichmentMap_NES_Data_Set_1_" : 1.5957,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9886,
        "EnrichmentMap_Genes" : [ "POLR2L", "GTF2A1", "CREB5", "TBP", "GTF2B", "TAF9", "GTF2F1", "POLR2C", "GTF2A2", "POLR2F", "PRKAR1B", "TTF1", "GTF2E1", "POLR2H", "GTF2E2", "TAF1C", "TAF9B", "CFAP20", "GTF2A1L", "BRF2", "BRF1", "TAF12", "MTERF2", "EP300", "TAF11", "POLR2E", "GTF2H1", "GTF2F2", "GTF2H4", "TTF2", "GTF2H3", "TAF8", "TBPL1", "TAF7", "TAF4", "TAF2", "PRKAR1A", "TBPL2", "PRKAR2B", "TAF6", "PRKAR2A", "CREB3L3", "CREB3L4", "CREB3L1", "CREB3L2", "CREBBP", "PSMC3IP" ],
        "name" : "TRANSCRIPTION REGULATION BY BZIP TRANSCRIPTION FACTOR%PANTHER PATHWAY%P00055",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176840,
        "selected" : false
      },
      "position" : {
        "x" : 301.6210342841812,
        "y" : 18.564775285841506
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176837",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0159,
        "EnrichmentMap_Name" : "PID_PDGFRA_PATHWAY%MSIGDB_C2%PID_PDGFRA_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.6985,
        "EnrichmentMap_GS_DESCR" : "PID_PDGFRA_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_PDGFRA_PATHWAY%MSIGDB_C2%PID_PDGFRA_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0035,
        "EnrichmentMap_gs_size" : 17,
        "EnrichmentMap_NES_Data_Set_1_" : -1.8125,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9965,
        "EnrichmentMap_Genes" : [ "GRB2", "SOS1", "SHC1", "CSNK2A1", "DKFZP434N101", "FOS", "CAV3", "SHB", "JUN", "RAPGEF1", "CRKL", "PIK3R1", "JAK1", "ITGAV", "IF2F", "CRK", "PDGFRA" ],
        "name" : "PID_PDGFRA_PATHWAY%MSIGDB_C2%PID_PDGFRA_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176837,
        "selected" : false
      },
      "position" : {
        "x" : 404.6384865241714,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176834",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "HETEROTRIMERIC G-PROTEIN SIGNALING PATHWAY-ROD OUTER SEGMENT PHOTOTRANSDUCTION%PANTHER PATHWAY%P00028",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8322,
        "EnrichmentMap_GS_DESCR" : "Heterotrimeric G-protein signaling pathway-rod outer segment phototransduction",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "HETEROTRIMERIC G-PROTEIN SIGNALING PATHWAY-ROD OUTER SEGMENT PHOTOTRANSDUCTION%PANTHER PATHWAY%P00028",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 30,
        "EnrichmentMap_NES_Data_Set_1_" : 2.3468,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "CNGA1", "GNAT1", "GNG2", "GNB2", "GNB4", "GNG13", "CALML3", "PDC", "GNB1", "GNGT1", "GNGT2", "GNB5", "PDE6G", "GNG10", "GNG3", "GNG5", "GNG4", "CALM1", "GNG7", "PDE6B", "GNG12", "GNG8", "CNGB1", "GRK1", "RGS9", "RCVRN", "CNGB3", "CNGA3", "RHO", "PDE6A" ],
        "name" : "HETEROTRIMERIC G-PROTEIN SIGNALING PATHWAY-ROD OUTER SEGMENT PHOTOTRANSDUCTION%PANTHER PATHWAY%P00028",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176834,
        "selected" : false
      },
      "position" : {
        "x" : 118.48977579647976,
        "y" : -411.92222994792314
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176831",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0319,
        "EnrichmentMap_Name" : "PID_ATM_PATHWAY%MSIGDB_C2%PID_ATM_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6491,
        "EnrichmentMap_GS_DESCR" : "PID_ATM_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_ATM_PATHWAY%MSIGDB_C2%PID_ATM_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.008,
        "EnrichmentMap_gs_size" : 29,
        "EnrichmentMap_NES_Data_Set_1_" : 1.6853,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.992,
        "EnrichmentMap_Genes" : [ "BRCA1", "RBBP8", "CHEK2", "NBN", "CDC25A", "RFWD2", "FANCD2", "KAT5", "MDC1", "ATM", "ABRAXAS1", "RNF8", "UIMC1", "MDM2", "HEL-S-1", "TP53BP1", "TERF2", "HEL-S-71", "BLM", "RAD17", "RAD9A", "TRIM28", "SMC1A", "TOP3A", "MRE11A", "CTBP1", "SMC3", "RAD50", "H2AX" ],
        "name" : "PID_ATM_PATHWAY%MSIGDB_C2%PID_ATM_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176831,
        "selected" : false
      },
      "position" : {
        "x" : -106.03959880297703,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176828",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6464,
        "EnrichmentMap_GS_DESCR" : "Validated targets of C-MYC transcriptional activation",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 79,
        "EnrichmentMap_NES_Data_Set_1_" : 2.1896,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "ODC1", "TRRAP", "PRDX3", "CDC25A", "ENO1", "TAF9", "EIF4E", "BMI1", "PEG10", "HSPD1", "FOSL1", "CCND2", "UBTF", "NCL", "RCC1", "RPL11", "IREB2", "CDCA7", "MTDH", "MYCT1", "PDCD10", "KIR3DL1", "LIN28B", "CDK4", "POLR3D", "TAF12", "NDUFAF2", "NME2", "SNAI1", "TAF4B", "TAF10", "SERPINI1", "NME1", "HSP90AA1", "RUVBL2", "SUPT3H", "EIF4A1", "PTMA", "PIM1", "RIOX2", "TFRC", "MAX", "DDX18", "SLC2A1", "BAX", "HMGA1", "ACTL6A", "SMAD4", "ID2", "TP53", "LDHA", "NBN", "GAPDH", "CCNB1", "EIF4G1", "NPM1", "SHMT1", "CAD", "KAT5", "HUWE1", "EP300", "EIF2S1", "PFKM", "GPAM", "E2F3", "SUPT7L", "MMP9", "RUVBL1", "MTA1", "MYC", "BCAT1", "TK1", "SMAD3", "PMAIP1", "KAT2A", "CREBBP", "BIRC5", "TERT", "HSPA4" ],
        "name" : "VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176828,
        "selected" : false
      },
      "position" : {
        "x" : 506.9600769477554,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176825",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "AURORA B SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA B SIGNALING",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7785,
        "EnrichmentMap_GS_DESCR" : "Aurora B signaling",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "AURORA B SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA B SIGNALING",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 40,
        "EnrichmentMap_NES_Data_Set_1_" : 2.3292,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "CENPA", "RASA1", "AURKA", "NCAPG", "CUL3", "KLHL13", "PEBP1", "AURKC", "NCL", "NCAPH", "PPP1CC", "RACGAP1", "STMN1", "EVI5", "SEPTIN1", "NPM1", "NSUN2", "CBX5", "PPP2R5D", "KLHL9", "PSMA3", "CDCA8", "DES", "H3-3B", "NCAPD2", "KIF2C", "TACC1", "VIM", "AURKB", "MYLK", "KIF20A", "KIF23", "SMC4", "INCENP", "BUB1", "NDC80", "SMC2", "SGO1", "RHOA", "BIRC5" ],
        "name" : "AURORA B SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA B SIGNALING",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176825,
        "selected" : false
      },
      "position" : {
        "x" : 609.2816673713394,
        "y" : 18.58195668232588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176822",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0672,
        "EnrichmentMap_Name" : "PID_ANGIOPOIETIN_RECEPTOR_PATHWAY%MSIGDB_C2%PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5366,
        "EnrichmentMap_GS_DESCR" : "PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_ANGIOPOIETIN_RECEPTOR_PATHWAY%MSIGDB_C2%PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0189,
        "EnrichmentMap_gs_size" : 38,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6351,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9811,
        "EnrichmentMap_Genes" : [ "SHC1", "ITGB1", "PLG", "MAPK8", "ANGPT4", "MAPK1", "NFKB1", "ANGPT2", "ELF2", "GRB14", "RPS6KB1", "FYN", "GRB7", "STAT5B", "PTPN11", "PXN", "F2", "CRK", "ANGPT1", "GRB2", "FGF2", "MMP2", "TNF", "AGTR1", "RAC1", "PLD2", "NCK1", "RELA", "PAK1", "CDKN1A", "FES", "DKFZP686H0575", "DKFZP666O0110", "FOXO1", "MAPK14", "PIK3R1", "BMX", "MAPK3" ],
        "name" : "PID_ANGIOPOIETIN_RECEPTOR_PATHWAY%MSIGDB_C2%PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176822,
        "selected" : false
      },
      "position" : {
        "x" : -528.7482627434067,
        "y" : 336.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176819",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0241,
        "EnrichmentMap_Name" : "TGF-BETA SIGNALING PATHWAY%PANTHER PATHWAY%P00052",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4318,
        "EnrichmentMap_GS_DESCR" : "TGF-beta signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "TGF-BETA SIGNALING PATHWAY%PANTHER PATHWAY%P00052",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0057,
        "EnrichmentMap_gs_size" : 85,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5693,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9943,
        "EnrichmentMap_Genes" : [ "SMAD6", "TGFBR1", "TGFB3", "MAPK12", "GDF2", "SMAD5", "SKI", "BMP8A", "BMP6", "GDF1", "BMP8B", "GDF3", "GDF6", "MAPK9", "GDF5", "INHBC", "BMPR1A", "MAPK8", "GDF7", "GDF15", "GDF9", "MAPK1", "BMP3", "TLL2", "TGFB2", "TLL1", "SNIP1", "MAPK13", "FOSL1", "NODAL", "MAPK11", "MSTN", "BMP15", "FOXH1", "SMAD2", "LEFTY1", "ACVR1C", "GDF10", "MAPK10", "GDF11", "CITED2", "ACVR1B", "TGFBR2", "CITED1", "JUND", "ACVRL1", "BMP10", "BMP7", "BMP5", "INHBA", "BMP4", "BMP1", "AMHR2", "SMAD4", "SMAD9", "BMPR1B", "DCP1B", "ATF2", "INHBE", "JUN", "RRAS", "INHBB", "BMP2", "EP300", "TAB1", "MAP3K7", "ACVR2A", "NRAS", "SMAD3", "GDNF", "ACVR2B", "MAPK14", "BMPR2", "SMAD7", "MAP3K7CL", "SKIL", "JUNB", "LEFTY2", "CREBBP", "ACVR1", "HRAS", "SMAD1", "SMURF2", "SMURF1", "MAPK3" ],
        "name" : "TGF-BETA SIGNALING PATHWAY%PANTHER PATHWAY%P00052",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176819,
        "selected" : false
      },
      "position" : {
        "x" : 581.2339607673355,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176816",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.008,
        "EnrichmentMap_Name" : "BIOCARTA_INTEGRIN_PATHWAY%MSIGDB_C2%BIOCARTA_INTEGRIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.6243,
        "EnrichmentMap_GS_DESCR" : "BIOCARTA_INTEGRIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BIOCARTA_INTEGRIN_PATHWAY%MSIGDB_C2%BIOCARTA_INTEGRIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0017,
        "EnrichmentMap_gs_size" : 30,
        "EnrichmentMap_NES_Data_Set_1_" : -1.8696,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9983,
        "EnrichmentMap_Genes" : [ "SOS1", "SHC1", "ITGB1", "ARHA", "ROCK1", "ACTN1", "MAPK8", "MAPK1", "BCR", "RAP1A", "JUN", "RAPGEF1", "FYN", "MAP2K1", "ZYX", "CRKL", "PPP1R12B", "MAP2K2", "GRB2", "TNS1", "TLN1", "ACTN2", "HEL114", "CSK", "RAF1", "ACTA1", "HRAS", "CAPNS1", "CAPNS2", "MAPK3" ],
        "name" : "BIOCARTA_INTEGRIN_PATHWAY%MSIGDB_C2%BIOCARTA_INTEGRIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176816,
        "selected" : false
      },
      "position" : {
        "x" : -528.7482627434067,
        "y" : 129.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176813",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0375,
        "EnrichmentMap_Name" : "RANKL%NETPATH%RANKL",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4363,
        "EnrichmentMap_GS_DESCR" : "RANKL",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "RANKL%NETPATH%RANKL",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0097,
        "EnrichmentMap_gs_size" : 21,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5564,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9903,
        "EnrichmentMap_Genes" : [ "CHUK", "MAP3K7", "TNFSF11", "TNFRSF11B", "MITF-C", "MAP3K7IP1", "MAPK8", "NFKB1", "TRAF3", "TRAF2", "NFKB2", "ATP6V1E1", "TRAF1", "DKFZP666O0110", "SPI1", "MAPK14", "REL", "SQSTM1", "TRAF6", "TRAF5", "TREM2" ],
        "name" : "RANKL%NETPATH%RANKL",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176813,
        "selected" : false
      },
      "position" : {
        "x" : -528.7482627434067,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176810",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0793,
        "EnrichmentMap_Name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043",
        "EnrichmentMap_ES_Data_Set_1_" : 0.4952,
        "EnrichmentMap_GS_DESCR" : "Muscarinic acetylcholine receptor 2 and 4 signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0228,
        "EnrichmentMap_gs_size" : 37,
        "EnrichmentMap_NES_Data_Set_1_" : 1.5219,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9772,
        "EnrichmentMap_Genes" : [ "GNAT1", "GNAI3", "GNAI2", "ADCY10", "KCNJ5", "GNB2", "KCNJ6", "KCNJ9", "GNB4", "PRKACB", "KCNJ3", "PRKAR1B", "GNB1", "GNGT2", "GNB5", "PRKACA", "GNG11", "GNG10", "PRKAR1A", "GNG3", "GNG5", "GNAO1", "PRKAR2B", "GNAI1", "GNG4", "GNG7", "SLC5A7", "PRKAR2A", "GNG8", "SLC18A3", "CHRM2", "PRKACG", "GNAT2", "GNB3", "SLC6A8", "CHRM4", "PRKX" ],
        "name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176810,
        "selected" : false
      },
      "position" : {
        "x" : 17.545021672792018,
        "y" : -385.67982882487627
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176807",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0336,
        "EnrichmentMap_Name" : "PNAT%PANTHER PATHWAY%P05912",
        "EnrichmentMap_ES_Data_Set_1_" : 0.557,
        "EnrichmentMap_GS_DESCR" : "PNAT",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PNAT%PANTHER PATHWAY%P05912",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0085,
        "EnrichmentMap_gs_size" : 45,
        "EnrichmentMap_NES_Data_Set_1_" : 1.7005,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9915,
        "EnrichmentMap_Genes" : [ "VAMP1", "SLC6A3", "CLIC6", "EPB41L2", "PPP1CA", "SNAP23", "GNAI3", "GNAI2", "VAMP8", "EPB41", "EPB41L1", "GNB2", "PRKACB", "GNB4", "PPP1CC", "FLNA", "EPB41L3", "VAMP3", "GNB1", "ADCY7", "PRKACA", "GNG11", "KCNK3", "KCNK9", "ADCY2", "GNG3", "VAMP2", "SNAP25", "PRKAR2B", "GNAI1", "GNG4", "PRKAR2A", "GNG8", "PRKACG", "PPP1R1B", "GNB3", "SLC18A2", "STX3", "DRD1", "SNAP29", "GNAZ", "DRD2", "DRD4", "PRKX", "DRD5" ],
        "name" : "PNAT%PANTHER PATHWAY%P05912",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176807,
        "selected" : false
      },
      "position" : {
        "x" : -162.02398524706882,
        "y" : -353.9251748942122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176804",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 2.0E-4,
        "EnrichmentMap_Name" : "BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7252,
        "EnrichmentMap_GS_DESCR" : "BARD1 signaling events",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 28,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0737,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "BRCA1", "RBBP8", "MRE11", "XRCC6", "TP53", "NBN", "CCNE1", "EWSR1", "PCNA", "PRKDC", "FANCD2", "CDK2", "ATM", "BARD1", "UBE2L3", "RAD51", "UBE2D3", "FANCL", "FANCA", "FANCE", "FANCG", "FANCF", "RAD50", "FANCC", "ATR", "TOPBP1", "XRCC5", "CSTF1" ],
        "name" : "BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176804,
        "selected" : false
      },
      "position" : {
        "x" : -528.7482627434067,
        "y" : -193.9936382197127
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176801",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PLK1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PLK1 SIGNALING EVENTS",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7959,
        "EnrichmentMap_GS_DESCR" : "PLK1 signaling events",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PLK1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PLK1 SIGNALING EVENTS",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 46,
        "EnrichmentMap_NES_Data_Set_1_" : 2.465,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "ECT2", "STAG2", "KIF2A", "CDK1", "TPT1", "BUB1B", "PPP1CB", "PLK1", "FZR1", "RAB1A", "AURKA", "CCNB1", "ERCC6L", "GOLGA2", "CLSPN", "NINL", "NUDC", "CENPU", "GORASP1", "KIZ", "ROCK2", "FBXW11", "PPP2R1A", "KIF20A", "CENPE", "CDC14B", "PAK1", "PRC1", "WEE1", "PPP2CA", "TUBG1", "BTRC", "INCENP", "BUB1", "PPP1R12A", "BORA", "ODF2", "CDC25C", "NDC80", "CDC25B", "CDC20", "FBXO5", "SGO1", "SPC24", "RHOA", "TPX2" ],
        "name" : "PLK1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PLK1 SIGNALING EVENTS",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176801,
        "selected" : false
      },
      "position" : {
        "x" : 98.60358204419094,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176798",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0848,
        "EnrichmentMap_Name" : "CASPASE CASCADE IN APOPTOSIS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CASPASE CASCADE IN APOPTOSIS",
        "EnrichmentMap_ES_Data_Set_1_" : 0.4873,
        "EnrichmentMap_GS_DESCR" : "Caspase cascade in apoptosis",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "CASPASE CASCADE IN APOPTOSIS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CASPASE CASCADE IN APOPTOSIS",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0247,
        "EnrichmentMap_gs_size" : 53,
        "EnrichmentMap_NES_Data_Set_1_" : 1.5093,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9753000000000001,
        "EnrichmentMap_Genes" : [ "APP", "CASP9", "CASP8", "NUMA1", "CASP3", "LMNB1", "PTK2", "CASP7", "CASP4", "SLK", "CASP2", "CASP1", "OPG199", "SPTAN1", "DFFA", "RIPK1", "TOP1", "XIAP", "LIMK1", "BIRC3", "SATB1", "MAP3K1", "CASP6", "CRADD", "LMNA", "TRADD", "BAX", "BIRC2", "KRT18", "ARHGDIB", "CYCS", "BCL2", "VIM", "PRF1", "CASP10", "SREBF1", "TNF", "MADD", "DIABLO", "TRAF2", "LMNB2", "CFL2", "BID", "TFAP2A", "TNFRSF1A", "DFFB", "GAS2", "PIDD1", "PARP1", "ACTA1", "GZMB", "GSN", "APAF1" ],
        "name" : "CASPASE CASCADE IN APOPTOSIS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CASPASE CASCADE IN APOPTOSIS",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176798,
        "selected" : false
      },
      "position" : {
        "x" : -426.4266723198227,
        "y" : 336.84696370136885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176795",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0722,
        "EnrichmentMap_Name" : "IL4%NETPATH%IL4",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4358,
        "EnrichmentMap_GS_DESCR" : "IL4",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "IL4%NETPATH%IL4",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0205,
        "EnrichmentMap_gs_size" : 39,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5033,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9795,
        "EnrichmentMap_Genes" : [ "CHUK", "SHC1", "ATF2", "SOCS1", "IL2RG", "H3-4", "MAPK8", "MAPK1", "NFKB1", "RPS6KB1", "NFKBIA", "PIK3CD", "MAPK11", "CEBPA", "STAT3", "BAD", "PTPN11", "IL4", "IL13RA1", "INPP5D", "PTPN6", "IKBKB", "SND1", "EP300", "IL13", "DKFZP666O0110", "MAPK14", "SPI1", "JAK1", "SYK", "TYK2", "CD40", "PLCG2", "CREBBP", "CBL", "H3C15", "MAPK3", "CXCR4", "CEBPB" ],
        "name" : "IL4%NETPATH%IL4",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176795,
        "selected" : false
      },
      "position" : {
        "x" : -428.7482627434067,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176792",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7252,
        "EnrichmentMap_GS_DESCR" : "Fanconi anemia pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 47,
        "EnrichmentMap_NES_Data_Set_1_" : 2.246,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "FAAP100", "FANCI", "HES1", "CHEK1", "RFC5", "RPA2", "BRCA1", "MRE11", "HUS1", "NBN", "FANCD2", "BRCA2", "FBXW11", "ATM", "USP1", "BLM", "XRCC3", "UBE2T", "WDR48", "RAD9A", "FAAP24", "RAD17", "BRIP1", "ATRIP", "FANCM", "FANCL", "RMI1", "TOP3A", "RPA1", "FANCA", "RFC3", "FANCB", "FANCE", "RFC2", "PALB2", "FANCG", "FANCF", "RAD50", "BTRC", "FAN1", "CENPS", "FANCC", "ATR", "TOPBP1", "RAD1", "RFC4", "H2AX" ],
        "name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176792,
        "selected" : false
      },
      "position" : {
        "x" : -375.434769014769,
        "y" : -314.2713663004622
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176789",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0164,
        "EnrichmentMap_Name" : "ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5185,
        "EnrichmentMap_GS_DESCR" : "Angiopoietin receptor Tie2-mediated signaling",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0036,
        "EnrichmentMap_gs_size" : 50,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7042,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9964,
        "EnrichmentMap_Genes" : [ "PTK2", "PLG", "RASA1", "FN1", "MAPK8", "ELK1", "ANGPT4", "NFKB1", "MAPK1", "ANGPT2", "ELF2", "RPS6KB1", "FYN", "STAT5B", "PTPN11", "F2", "CRK", "ETS1", "DOK2", "GRB2", "FGF2", "TEK", "RELA", "PAK1", "FOXO1", "ITGA5", "BMX", "NOS3", "SHC1", "ITGB1", "TNIP2", "GRB14", "GRB7", "ELF1", "PXN", "ANGPT1", "MMP2", "TNF", "RAC1", "AGTR1", "PLD2", "AKT1", "NCK1", "CDKN1A", "FES", "PIK3CA", "MAPK14", "STAT5A", "PIK3R1", "MAPK3" ],
        "name" : "ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176789,
        "selected" : false
      },
      "position" : {
        "x" : -526.4266723198227,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176786",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0031,
        "EnrichmentMap_Name" : "SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5103,
        "EnrichmentMap_GS_DESCR" : "Signaling events mediated by focal adhesion kinase",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE",
        "EnrichmentMap_pvalue_Data_Set_1_" : 6.0E-4,
        "EnrichmentMap_gs_size" : 58,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7973,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9994,
        "EnrichmentMap_Genes" : [ "ASAP1", "BCAR1", "SOS1", "SRC", "VCL", "SH3GL1", "MAPK9", "ARHGAP26", "PTK2", "KLF8", "RASA1", "MAPK8", "MAPK1", "FYN", "PTPN21", "MAP2K1", "CRK", "ETS1", "GRB2", "BRAF", "PAK1", "TLN1", "ITGA5", "ARHGEF7", "BMX", "GIT2", "ITGB1", "ACTN1", "ARHGEF28", "ARHGAP35", "ITGB5", "RAP1A", "JUN", "RAPGEF1", "GRB7", "YES1", "RRAS", "PXN", "ROCK2", "ITGAV", "WASL", "MAPK8IP3", "NCK2", "MAP2K4", "RAC1", "CCND1", "NCK1", "ARHGEF11", "ELMO1", "RAP1B", "PIK3CA", "PIK3R1", "RAF1", "DOCK1", "ACTA1", "PLCG1", "CAPN2", "RHOA" ],
        "name" : "SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176786,
        "selected" : false
      },
      "position" : {
        "x" : -515.325960497313,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176783",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.078,
        "EnrichmentMap_Name" : "CD40 CD40L SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CD40 CD40L SIGNALING",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5273,
        "EnrichmentMap_GS_DESCR" : "CD40 CD40L signaling",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "CD40 CD40L SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CD40 CD40L SIGNALING",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0224,
        "EnrichmentMap_gs_size" : 36,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6067,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9776,
        "EnrichmentMap_Genes" : [ "BCL2L1", "MAPK9", "MAPK8", "NFKB1", "TNFAIP3", "JUN", "NFKBIA", "MAPK11", "JAK3", "IL4", "MAPK10", "CBLB", "CD40LG", "TDP2", "PIK3CB", "PIK3CG", "BIRC3", "MAP2K4", "MAP3K1", "AKT1", "RELA", "MYC", "TRAF3", "TRAF2", "PIK3CA", "TRAF1", "C4BPA", "MAPK14", "FCAMR", "BIRC2", "STAT5A", "CD40", "PIK3R1", "PIK3R6", "TRAF6", "MAP3K14" ],
        "name" : "CD40 CD40L SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CD40 CD40L SIGNALING",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176783,
        "selected" : false
      },
      "position" : {
        "x" : -328.7482627434067,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176780",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0019,
        "EnrichmentMap_Name" : "UBIQUITIN PROTEASOME PATHWAY%PANTHER PATHWAY%P00060",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5968,
        "EnrichmentMap_GS_DESCR" : "Ubiquitin proteasome pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "UBIQUITIN PROTEASOME PATHWAY%PANTHER PATHWAY%P00060",
        "EnrichmentMap_pvalue_Data_Set_1_" : 3.0E-4,
        "EnrichmentMap_gs_size" : 27,
        "EnrichmentMap_NES_Data_Set_1_" : 1.8335,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9997,
        "EnrichmentMap_Genes" : [ "UBE2L6", "UBA2", "UBE2D2", "UBE2N", "SAE1", "UBE2G1", "UBE2G2", "UBE2D4", "UBE2C", "UBA6", "UBE2NL", "UBE2L3", "ATG7", "UBA3", "UBE2B", "UBE2E3", "UBE2T", "UBE2E2", "UBE2V2", "UBA1", "UBA7", "UBE2D3", "UBE2K", "UBE2D1", "UBE2E1", "UBE2A", "UBE2S" ],
        "name" : "UBIQUITIN PROTEASOME PATHWAY%PANTHER PATHWAY%P00060",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176780,
        "selected" : false
      },
      "position" : {
        "x" : -228.7482627434067,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176777",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0961,
        "EnrichmentMap_Name" : "IL6%NETPATH%IL6",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4044,
        "EnrichmentMap_GS_DESCR" : "IL6",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "IL6%NETPATH%IL6",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0287,
        "EnrichmentMap_gs_size" : 58,
        "EnrichmentMap_NES_Data_Set_1_" : -1.4541,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9713,
        "EnrichmentMap_Genes" : [ "RB1", "IL6ST", "SOCS3", "FOS", "CDK9", "MAPK8", "HEL-S-102", "MAPK1", "NFKB1", "EIF4E", "RPS6KB1", "FYN", "MAP2K6", "STAT1", "MAP2K1", "STAT5B", "STAT3", "FOXO3A", "PTPN11", "MAP2K2", "VAV1", "FOXO4", "GRB2", "DKFZP434N101", "IL6R", "GSK3B", "ERBB3", "ERBB2", "BTK", "FOXO1", "SGK1", "CD40", "JAK1", "TYK2", "PTK2B", "IL6", "BMX", "CBL", "EIF2A", "SHC1", "EIF4EBP1", "LYN", "JUN", "BAD", "EP300", "MAP2K4", "RAC1", "MAP3K7", "GAB2", "NLK", "MAPK14", "HDAC1", "PIK3R2", "NCOA1", "PIK3R1", "CREBBP", "C-FGR", "MAPK3" ],
        "name" : "IL6%NETPATH%IL6",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176777,
        "selected" : false
      },
      "position" : {
        "x" : 449.1174737411209,
        "y" : -318.0539361857161
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176774",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.034,
        "EnrichmentMap_Name" : "ALPHA6BETA4INTEGRIN%NETPATH%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4586,
        "EnrichmentMap_GS_DESCR" : "Alpha6Beta4Integrin",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ALPHA6BETA4INTEGRIN%NETPATH%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0087,
        "EnrichmentMap_gs_size" : 58,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6048,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9913,
        "EnrichmentMap_Genes" : [ "SRC", "CD151", "FOS", "EGFR", "CASP3", "ARHA", "MAPK1", "EIF4E", "FYN", "PIK3CD", "SMAD2", "PTPN11", "HEL113", "GRB2", "PAK1", "ERBB2", "HEL2", "DKFZP666O0110", "MET", "SHC1", "EIF4EBP1", "LAMB3", "SFN", "EPHB2", "RTKN", "MYLK3", "RPSA", "JUN", "LAMC2", "LAMA5", "LAMC1", "YWHAQ", "ITGA6", "COL17A1", "NTN1", "CLCA1", "YES1", "PLEC", "LAMB2", "BAD", "ERBIN", "LAMB1", "MTOR", "EIF6", "TP73", "YWHAZ", "HEL-S-1", "RAC1", "DST", "IRS1", "ITGB4", "MAPK14", "PIK3R2", "LAMA3", "PIK3R1", "PRKCA", "MAPK3", "PIK3R3" ],
        "name" : "ALPHA6BETA4INTEGRIN%NETPATH%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176774,
        "selected" : false
      },
      "position" : {
        "x" : -323.4092200798325,
        "y" : 336.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176771",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.01,
        "EnrichmentMap_Name" : "INSULIN IGF PATHWAY-PROTEIN KINASE B SIGNALING CASCADE%PANTHER PATHWAY%P00033",
        "EnrichmentMap_ES_Data_Set_1_" : -0.6828,
        "EnrichmentMap_GS_DESCR" : "Insulin IGF pathway-protein kinase B signaling cascade",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "INSULIN IGF PATHWAY-PROTEIN KINASE B SIGNALING CASCADE%PANTHER PATHWAY%P00033",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0021,
        "EnrichmentMap_gs_size" : 22,
        "EnrichmentMap_NES_Data_Set_1_" : -1.8683,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9979,
        "EnrichmentMap_Genes" : [ "IGF2", "MDM2", "IRS4", "GSK3B", "INSRR", "TPTE", "IRS2", "INSR", "TSC1", "GSK3A", "FOXO3", "TSC2", "IRS1", "PIK3CA", "FOXO1", "IGF1R", "INS", "MDM4", "PDPK1", "PTEN", "IGF1", "IGF2R" ],
        "name" : "INSULIN IGF PATHWAY-PROTEIN KINASE B SIGNALING CASCADE%PANTHER PATHWAY%P00033",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176771,
        "selected" : false
      },
      "position" : {
        "x" : -128.7482627434067,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176768",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 5.0E-4,
        "EnrichmentMap_Name" : "AURORA A SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA A SIGNALING",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7076,
        "EnrichmentMap_GS_DESCR" : "Aurora A signaling",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "AURORA A SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA A SIGNALING",
        "EnrichmentMap_pvalue_Data_Set_1_" : 1.0E-4,
        "EnrichmentMap_gs_size" : 31,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0358,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9999,
        "EnrichmentMap_Genes" : [ "BRCA1", "TDRD7", "TP53", "FZR1", "CENPA", "RASA1", "OAZ1", "AURKAIP1", "AURKA", "AJUBA", "NFKBIA", "GADD45A", "PPP2R5D", "CPEB1", "TACC1", "AURKB", "PRKACA", "MDM2", "DLGAP5", "GSK3B", "AKT1", "PAK1", "NDEL1", "CKAP5", "TACC3", "ARHGEF7", "GIT1", "CDC25B", "RAN", "BIRC5", "TPX2" ],
        "name" : "AURORA A SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA A SIGNALING",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176768,
        "selected" : false
      },
      "position" : {
        "x" : -221.0876296562485,
        "y" : 336.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176765",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0267,
        "EnrichmentMap_Name" : "TNFALPHA%NETPATH%TNFALPHA",
        "EnrichmentMap_ES_Data_Set_1_" : 0.3681,
        "EnrichmentMap_GS_DESCR" : "TNFalpha",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "TNFALPHA%NETPATH%TNFALPHA",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0065,
        "EnrichmentMap_gs_size" : 172,
        "EnrichmentMap_NES_Data_Set_1_" : 1.4375,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9935,
        "EnrichmentMap_Genes" : [ "SOS1", "RB1", "KPNA2", "SMARCC1", "MAP2K5", "G3BP2", "RPL30", "FLNA", "FBXW7", "ROMO1", "TRIM32", "LRPPRC", "RFFL", "TNFRSF8", "PRC1", "TXNIP", "TRIB3", "NUPR1", "HEL2", "MAPKAPK2", "FADD", "CYBA", "UBE2I", "PKN1", "FAF1", "MAP3K5", "NFKBIZ", "CSNK2A1", "TNFRSF1B", "JUN", "KIAA0287", "YWHAZ", "TBK1", "EP300", "CASP10", "HEL-S-1", "TNF", "CDC37", "BRINP1", "DIABLO", "COPB2", "MTIF2", "IKBKAP", "IKBKG", "HDAC1", "PSMD12", "MAP3K8", "PSMD13", "TXN", "CREBBP", "JUNB", "NR2C2", "MAPK3", "BCL2L1", "SRC", "POLR1C", "CDK9", "POLR1D", "EGFR", "CASP3", "MAPK9", "CASP2", "MAPK8", "MAP3K7IP1", "HEL-S-102", "NFKB1", "MAPK1", "UBE2D2", "TRAF4", "NFKBIA", "MAP2K6", "STAT1", "PTPN11", "REL", "POLR2H", "DOK1", "NFKBIE", "CREB1", "GRB2", "BIRC3", "RXRA", "SUMO1", "RPL6", "GLG1", "FBL", "BAG4", "PSMD7", "CRADD", "SEC16A", "PAK1", "MCC", "ERBB3", "UBE2D3", "SMARCA4", "PSMD3", "ALPL", "PSMD1", "TAB3", "PPP6C", "FOXO1", "RNF11", "BCL7A", "DKFZP666O0110", "PPP1R13L", "NKIRAS2", "BAX", "IKBKE", "BIRC2", "RIPK3", "ACTL6A", "COMMD1", "RASA3", "NKIRAS1", "MUXA", "POLR1A", "TRAF6", "TANK", "YWHAG", "TRAF5", "FKBP5", "PFDN2", "RELB", "AKAP8", "TIFA", "POLR2L", "MAP3K2", "SMARCE1", "RNF25", "KTN1", "PSMC1", "ITCH", "PDCD2", "TBKBP1", "RPL4", "ZFAND5", "RPL8", "DKFZP566E044", "DCAF7", "MCM7", "PSMD6", "TNIP2", "PSMD2", "DKFZP781N011", "PAPOLA", "KPNA6", "HSP90AB1", "DPF2", "RPS11", "YWHAQ", "KPNA3", "RPS13", "MAP3K11", "GTF2I", "SMARCC2", "USP2", "TRPC4AP", "TXLNA", "MCM5", "FANCD2", "SKP1", "NSMAF", "TNFRSF11A", "FBXW11", "HDAC2", "DDX3X", "IRS1", "MAPK14", "PML", "CDC34", "PRKCA", "SOS2", "RPS6KA5" ],
        "name" : "TNFALPHA%NETPATH%TNFALPHA",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176765,
        "selected" : false
      },
      "position" : {
        "x" : -208.361189226561,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176762",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0844,
        "EnrichmentMap_Name" : "BIOCARTA_NFAT_PATHWAY%MSIGDB_C2%BIOCARTA_NFAT_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5092,
        "EnrichmentMap_GS_DESCR" : "BIOCARTA_NFAT_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "BIOCARTA_NFAT_PATHWAY%MSIGDB_C2%BIOCARTA_NFAT_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0246,
        "EnrichmentMap_gs_size" : 41,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5463,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9754,
        "EnrichmentMap_Genes" : [ "HEL-S-99N", "MYH2", "NPPA", "HAND2", "HAND1", "MAPK8", "MAPK1", "RPS6KB1", "HBEGF", "MEF2C", "CTF1", "MAP2K1", "PRKAR1B", "F2", "NFATC3", "NFATC4", "CAMK4", "FGF2", "NFATC2", "GSK3B", "HEL-S-72", "PRKAR1A", "CALM1", "EDN1", "PRKACG", "MAPK14", "GATA4", "PIK3R1", "RAF1", "NFATC1", "CREBBP", "CSNK1A1", "CAMK1", "PPP3CA", "ACTA1", "IGF1", "HRAS", "CAMK1G", "PPP3CC", "MAPK3", "NKX2-5" ],
        "name" : "BIOCARTA_NFAT_PATHWAY%MSIGDB_C2%BIOCARTA_NFAT_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176762,
        "selected" : false
      },
      "position" : {
        "x" : -28.748262743406713,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176759",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 3.0E-4,
        "EnrichmentMap_Name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7392,
        "EnrichmentMap_GS_DESCR" : "PID_BARD1_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 26,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0573,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "BRCA1", "RBBP8", "NBN", "CCNE1", "EWSR1", "PCNA", "PRKDC", "FANCD2", "CDK2", "ATM", "BARD1", "UBE2L3", "RAD51", "UBE2D3", "FANCL", "FANCA", "MRE11A", "FANCE", "FANCG", "FANCF", "RAD50", "FANCC", "ATR", "TOPBP1", "XRCC5", "CSTF1" ],
        "name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176759,
        "selected" : false
      },
      "position" : {
        "x" : -451.8691047233872,
        "y" : -273.8268625162825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176756",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0297,
        "EnrichmentMap_Name" : "PID_INSULIN_PATHWAY%MSIGDB_C2%PID_INSULIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5423,
        "EnrichmentMap_GS_DESCR" : "PID_INSULIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_INSULIN_PATHWAY%MSIGDB_C2%PID_INSULIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0074,
        "EnrichmentMap_gs_size" : 38,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7238,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9926,
        "EnrichmentMap_Genes" : [ "SOS1", "SHC1", "EIF4EBP1", "PARD6A", "PTPN1", "RAPGEF1", "TRIP10", "GRB14", "RPS6KB1", "GRB10", "FOXO3A", "PTPN11", "DOK1", "CRK", "EXOC2", "PRKCZ", "DKFZP762K123", "GRB2", "PRKCI", "NCK2", "DKFZP686P1551", "EXOC6", "F2RL2", "NCK1", "EXOC5", "INSR", "EXOC1", "PTPRA", "HEL-S-42", "IRS1", "INS", "SGK1", "PDPK1", "PIK3R1", "HRAS", "SH2B2", "CBL", "EXOC4" ],
        "name" : "PID_INSULIN_PATHWAY%MSIGDB_C2%PID_INSULIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176756,
        "selected" : false
      },
      "position" : {
        "x" : -413.004370073729,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176753",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0498,
        "EnrichmentMap_Name" : "CELL CYCLE%PANTHER PATHWAY%P00013",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6773,
        "EnrichmentMap_GS_DESCR" : "Cell cycle",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "CELL CYCLE%PANTHER PATHWAY%P00013",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0134,
        "EnrichmentMap_gs_size" : 5,
        "EnrichmentMap_NES_Data_Set_1_" : 1.65,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9866,
        "EnrichmentMap_Genes" : [ "CCND3", "CCND2", "RPA3", "CINP", "CCNE1" ],
        "name" : "CELL CYCLE%PANTHER PATHWAY%P00013",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176753,
        "selected" : false
      },
      "position" : {
        "x" : 71.25173725659329,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176750",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0292,
        "EnrichmentMap_Name" : "PID_EPHA2_FWD_PATHWAY%MSIGDB_C2%PID_EPHA2_FWD_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.6713,
        "EnrichmentMap_GS_DESCR" : "PID_EPHA2_FWD_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_EPHA2_FWD_PATHWAY%MSIGDB_C2%PID_EPHA2_FWD_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0072,
        "EnrichmentMap_gs_size" : 16,
        "EnrichmentMap_NES_Data_Set_1_" : -1.742,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9928,
        "EnrichmentMap_Genes" : [ "GRB2", "SHC1", "SRC", "RAC1", "VAV3", "ARHA", "PAK1", "ARHGAP35", "TIAM1", "DKFZP666O0110", "EFNA1", "EPHA2", "PIK3R1", "INPPL1", "CBL", "VAV2" ],
        "name" : "PID_EPHA2_FWD_PATHWAY%MSIGDB_C2%PID_EPHA2_FWD_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176750,
        "selected" : false
      },
      "position" : {
        "x" : 171.2517372565933,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176747",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0533,
        "EnrichmentMap_Name" : "PID_AVB3_INTEGRIN_PATHWAY%MSIGDB_C2%PID_AVB3_INTEGRIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4518,
        "EnrichmentMap_GS_DESCR" : "PID_AVB3_INTEGRIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_AVB3_INTEGRIN_PATHWAY%MSIGDB_C2%PID_AVB3_INTEGRIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0144,
        "EnrichmentMap_gs_size" : 62,
        "EnrichmentMap_NES_Data_Set_1_" : -1.528,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9856,
        "EnrichmentMap_Genes" : [ "SRC", "CASP8", "ARHA", "ROCK1", "VEGFA", "MAPK1", "COL3A1", "RPS6KB1", "COL16A1", "COL2A1", "PTPN11", "COL12A1", "TGFBR2", "FGF2", "COL4A4", "COL4A3", "COL4A6", "COL4A5", "CDKN1B", "TLN1", "DKFZP666O0110", "HEL114", "COL1A1", "PTK2B", "COL4A1", "COL8A2", "COL1A2", "CBL", "ANGPTL3", "COL5A2", "F11R", "MFGE8", "ITGB3", "COL6A1", "COL17A1", "COL14A1", "PXN", "COL10A1", "PI4KB", "ITGAV", "COL8A1", "COL13A1", "COL11A2", "COL9A3", "EDIL3", "COL9A2", "PIK3C2A", "RAC1", "SDC1", "COL9A1", "VAV3", "HEL-S-28", "CSF1", "IRS1", "TEM5", "IGF1R", "VTN", "CSF1R", "PIK3R1", "SPP1", "MAPK3", "KDR" ],
        "name" : "PID_AVB3_INTEGRIN_PATHWAY%MSIGDB_C2%PID_AVB3_INTEGRIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176747,
        "selected" : false
      },
      "position" : {
        "x" : 271.2517372565933,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176744",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_ATR_PATHWAY%MSIGDB_C2%PID_ATR_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8369,
        "EnrichmentMap_GS_DESCR" : "PID_ATR_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_ATR_PATHWAY%MSIGDB_C2%PID_ATR_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 34,
        "EnrichmentMap_NES_Data_Set_1_" : 2.4077,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "CHEK1", "PLK1", "HUS1", "NBN", "MCM7", "CDC25A", "TIMELESS", "CCNA2", "SMARCAL1", "CEP164", "CLSPN", "PPP2R2B", "YWHAZ", "FANCD2", "BRCA2", "MCM2", "FBXW11", "CDK2", "MDM2", "HEL-S-1", "PPP2R1A", "RAD51", "RAD17", "RAD9A", "ATRIP", "RPA1", "RFC3", "RFC2", "PPP2CA", "ATR", "CDC6", "TOPBP1", "RAD1", "RFC4" ],
        "name" : "PID_ATR_PATHWAY%MSIGDB_C2%PID_ATR_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176744,
        "selected" : false
      },
      "position" : {
        "x" : -331.54928431933445,
        "y" : -536.3361246012435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176741",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_MYC_ACTIV_PATHWAY%MSIGDB_C2%PID_MYC_ACTIV_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6356,
        "EnrichmentMap_GS_DESCR" : "PID_MYC_ACTIV_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_MYC_ACTIV_PATHWAY%MSIGDB_C2%PID_MYC_ACTIV_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 69,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0576,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "HEL-S-162EP", "HEL-S-133P", "TRRAP", "PRDX3", "CDC25A", "TAF9", "BMI1", "EIF4E", "PEG10", "UBTF", "HSPD1", "CCND2", "FOSL1", "NCL", "RCC1", "PTMAP7", "RPL11", "IREB2", "CDCA7", "MTDH", "MDIG", "MYCT1", "PDCD10", "KIR3DL1", "LIN28B", "CDK4", "POLR3D", "NME2", "NDUFAF2", "TAF12", "SNAI1", "TAF4B", "SERPINI1", "TAF10", "RUVBL2", "DKFZP686O0451", "EIF4A1", "PIM1", "MAX", "BAX", "HMGA1", "ACTL6A", "SMAD4", "ID2", "NBN", "CCNB1", "EIF4G1", "SHMT1", "CAD", "KAT5", "HUWE1", "EP300", "EIF2S1", "PFKM", "GPAM", "E2F3", "SUPT7L", "MMP9", "RUVBL1", "MYC", "BCAT1", "TK1", "PMAIP1", "KAT2A", "CREBBP", "HEL-S-17", "BIRC5", "TERT", "HSPA4" ],
        "name" : "PID_MYC_ACTIV_PATHWAY%MSIGDB_C2%PID_MYC_ACTIV_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176741,
        "selected" : false
      },
      "position" : {
        "x" : 509.2816673713394,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176738",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0479,
        "EnrichmentMap_Name" : "PDGFR-ALPHA SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PDGFR-ALPHA SIGNALING PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.624,
        "EnrichmentMap_GS_DESCR" : "PDGFR-alpha signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PDGFR-ALPHA SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PDGFR-ALPHA SIGNALING PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0127,
        "EnrichmentMap_gs_size" : 21,
        "EnrichmentMap_NES_Data_Set_1_" : -1.7325,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9873,
        "EnrichmentMap_Genes" : [ "GRB2", "SOS1", "CAV1", "SHC1", "CSNK2A1", "SHF", "CAV3", "FOS", "ELK1", "SHB", "RAPGEF1", "PIK3CA", "JUN", "CRKL", "JAK1", "PIK3R1", "ITGAV", "CRK", "PLCG1", "SRF", "PDGFRA" ],
        "name" : "PDGFR-ALPHA SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PDGFR-ALPHA SIGNALING PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176738,
        "selected" : false
      },
      "position" : {
        "x" : 406.9600769477554,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176735",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.002,
        "EnrichmentMap_Name" : "PID_AURORA_A_PATHWAY%MSIGDB_C2%PID_AURORA_A_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7251,
        "EnrichmentMap_GS_DESCR" : "PID_AURORA_A_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_AURORA_A_PATHWAY%MSIGDB_C2%PID_AURORA_A_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 4.0E-4,
        "EnrichmentMap_gs_size" : 25,
        "EnrichmentMap_NES_Data_Set_1_" : 1.9125,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9996,
        "EnrichmentMap_Genes" : [ "BRCA1", "TDRD7", "DKFZP686G14213", "FZR1", "CENPA", "OAZ1", "AURKAIP1", "AURKA", "AJUBA", "NFKBIA", "GADD45A", "DKFZP686K18126", "PPP2R5D", "AURKB", "MDM2", "DLGAP5", "GSK3B", "PAK1", "NDEL1", "KIAA0142", "CKAP5", "TACC3", "HCTP4", "RAN", "BIRC5" ],
        "name" : "PID_AURORA_A_PATHWAY%MSIGDB_C2%PID_AURORA_A_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176735,
        "selected" : false
      },
      "position" : {
        "x" : -218.76603923266453,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176732",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0587,
        "EnrichmentMap_Name" : "ALPHA6BETA4INTEGRIN%IOB%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4519,
        "EnrichmentMap_GS_DESCR" : "Alpha6Beta4Integrin",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "ALPHA6BETA4INTEGRIN%IOB%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0161,
        "EnrichmentMap_gs_size" : 53,
        "EnrichmentMap_NES_Data_Set_1_" : -1.541,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9839,
        "EnrichmentMap_Genes" : [ "SRC", "CD151", "EGFR", "CASP3", "ARHA", "EIF4E", "FYN", "PIK3CD", "SMAD2", "PTPN11", "HEL113", "GRB2", "PAK1", "ERBB2", "HEL2", "DKFZP666O0110", "MET", "SHC1", "EIF4EBP1", "LAMB3", "SFN", "EPHB2", "RTKN", "MYLK3", "RPSA", "LAMC2", "LAMA5", "LAMC1", "YWHAQ", "ITGA6", "COL17A1", "NTN1", "CLCA1", "YES1", "PLEC", "LAMB2", "BAD", "ERBIN", "LAMB1", "MTOR", "EIF6", "YWHAZ", "TP73", "HEL-S-1", "RAC1", "DST", "IRS1", "ITGB4", "PIK3R2", "LAMA3", "PIK3R1", "PRKCA", "PIK3R3" ],
        "name" : "ALPHA6BETA4INTEGRIN%IOB%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176732,
        "selected" : false
      },
      "position" : {
        "x" : -321.0876296562485,
        "y" : 229.12479573261885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176729",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0339,
        "EnrichmentMap_Name" : "IONOTROPIC GLUTAMATE RECEPTOR PATHWAY%PANTHER PATHWAY%P00037",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5821,
        "EnrichmentMap_GS_DESCR" : "Ionotropic glutamate receptor pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "IONOTROPIC GLUTAMATE RECEPTOR PATHWAY%PANTHER PATHWAY%P00037",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0086,
        "EnrichmentMap_gs_size" : 35,
        "EnrichmentMap_NES_Data_Set_1_" : 1.6816,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9914,
        "EnrichmentMap_Genes" : [ "VAMP1", "GRM3", "GRM2", "SLC1A1", "SNAP23", "VAMP8", "SHANK3", "SHANK1", "VAMP3", "GRIA1", "STX19", "SLC1A3", "SLC1A6", "SLC1A7", "GRIN2C", "STX11", "GRIN2B", "GRIN2D", "GRIN3A", "SLC17A6", "SLC17A8", "GRIK5", "SLC1A2", "GRIA3", "GRIK3", "GRIA4", "GRIK4", "GRIK1", "GRIK2", "VAMP2", "SNAP25", "GRIN1", "GRIN2A", "GRIA2", "SNAP29" ],
        "name" : "IONOTROPIC GLUTAMATE RECEPTOR PATHWAY%PANTHER PATHWAY%P00037",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176729,
        "selected" : false
      },
      "position" : {
        "x" : -139.55399928515476,
        "y" : -536.3361246012435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176726",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.001,
        "EnrichmentMap_Name" : "PID_AURORA_B_PATHWAY%MSIGDB_C2%PID_AURORA_B_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7706,
        "EnrichmentMap_GS_DESCR" : "PID_AURORA_B_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_AURORA_B_PATHWAY%MSIGDB_C2%PID_AURORA_B_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 2.0E-4,
        "EnrichmentMap_gs_size" : 28,
        "EnrichmentMap_NES_Data_Set_1_" : 1.9661,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9998,
        "EnrichmentMap_Genes" : [ "KNTC2", "ARHA", "CENPA", "AURKA", "TMP_LOCUS_29", "NCAPG", "KLHL13", "AURKC", "NCL", "PPP1CC", "SGOL1", "DKFZP686K18126", "SEPTIN1", "NSUN2", "PPP2R5D", "KLHL9", "CDCA8", "HEL113", "AURKB", "HEL25", "MYLK", "KIF20A", "KIF23", "HEL-S-34", "SMC4", "INCENP", "SMC2", "BIRC5" ],
        "name" : "PID_AURORA_B_PATHWAY%MSIGDB_C2%PID_AURORA_B_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176726,
        "selected" : false
      },
      "position" : {
        "x" : 611.6032577949234,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176723",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0829,
        "EnrichmentMap_Name" : "LEPTIN%NETPATH%LEPTIN",
        "EnrichmentMap_ES_Data_Set_1_" : -0.3713,
        "EnrichmentMap_GS_DESCR" : "Leptin",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "LEPTIN%NETPATH%LEPTIN",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.024,
        "EnrichmentMap_gs_size" : 44,
        "EnrichmentMap_NES_Data_Set_1_" : -1.3803,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.976,
        "EnrichmentMap_Genes" : [ "CHUK", "SHC1", "SRC", "IRS4", "EIF4EBP1", "CRP", "EGFR", "MAPK8", "ITGB5", "MAPK1", "EIF4E", "RPS6KB1", "FYN", "NFKBIA", "STAT1", "JAK3", "LIMK1", "IKBKB", "KHDRBS1", "ACACB", "SH2B1", "GRB2", "RUNX2", "DKFZP434N101", "GSK3B", "RPS6KA2", "CDK5", "LEP", "GSK3A", "ERBB2", "IRS1", "CFL2", "PDE3A", "SOCS7", "DKFZP666O0110", "IGF1R", "SLC2A4", "RPS6", "JAK1", "NCOA1", "PRKCE", "PLCG2", "PRKAA2", "PRKAA1" ],
        "name" : "LEPTIN%NETPATH%LEPTIN",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176723,
        "selected" : false
      },
      "position" : {
        "x" : 371.2517372565933,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176720",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8575,
        "EnrichmentMap_GS_DESCR" : "PID_CONE_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 21,
        "EnrichmentMap_NES_Data_Set_1_" : 2.1089,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "GUCY2D", "SLC24A2", "PDE6H", "DKFZP686E1183", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "GNAT2", "RGS9BP", "RDH12", "GRK7", "PDE6C", "CNGB3", "GNB3", "RDH5", "CNGA3", "LRAT", "GNGT2", "GNB5", "ARR3" ],
        "name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176720,
        "selected" : false
      },
      "position" : {
        "x" : 266.6176215606399,
        "y" : -536.3361246012435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176717",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0369,
        "EnrichmentMap_Name" : "NICOTINE PHARMACODYNAMICS PATHWAY%PANTHER PATHWAY%P06587",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6466,
        "EnrichmentMap_GS_DESCR" : "Nicotine pharmacodynamics pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "NICOTINE PHARMACODYNAMICS PATHWAY%PANTHER PATHWAY%P06587",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0095,
        "EnrichmentMap_gs_size" : 26,
        "EnrichmentMap_NES_Data_Set_1_" : 1.6789,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9905,
        "EnrichmentMap_Genes" : [ "CLIC6", "EPB41L2", "PPP1CA", "EPB41", "CACNA1C", "EPB41L1", "GNG2", "FLNA", "GNB1", "CACNA1G", "PRKACA", "KCNK3", "KCNK9", "ADCY2", "GNAI1", "CHRNA3", "CHRNA4", "CHRNA6", "CHRNB2", "CHRNB4", "PPP1R1B", "SLC18A2", "CHRNB3", "CHRNA5", "DRD2", "DRD4" ],
        "name" : "NICOTINE PHARMACODYNAMICS PATHWAY%PANTHER PATHWAY%P06587",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176717,
        "selected" : false
      },
      "position" : {
        "x" : -231.54928431933445,
        "y" : -266.16920870768877
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176714",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0067,
        "EnrichmentMap_Name" : "INTERLEUKIN SIGNALING PATHWAY%PANTHER PATHWAY%P00036",
        "EnrichmentMap_ES_Data_Set_1_" : -0.4645,
        "EnrichmentMap_GS_DESCR" : "Interleukin signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "INTERLEUKIN SIGNALING PATHWAY%PANTHER PATHWAY%P00036",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0014,
        "EnrichmentMap_gs_size" : 85,
        "EnrichmentMap_NES_Data_Set_1_" : -1.6864,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9986,
        "EnrichmentMap_Genes" : [ "SOS1", "IL6ST", "MAPK7", "RPS6KA6", "IL13RA2", "IRS2", "FOS", "IL1A", "ELK1", "MAPK1", "CXCR2", "STAT1", "JAK3", "IL20RA", "STAT5B", "STAT2", "STAT3", "IL18", "MKNK2", "IL4", "IL21", "SPIC", "IL11RA", "IL4R", "STAT6", "AKT2", "IL6R", "BRAF", "GSK3B", "RPS6KA2", "CDKN1B", "IL5RA", "MAPK6", "MAPKAPK2", "SPI1", "SLA2", "IL3RA", "IL6", "NOS3", "CHUK", "IL12RB1", "IL10", "SHC1", "IL10RB", "IL2RA", "CXCL8", "ELK4", "MKNK1", "IL7", "MAPK15", "IL2", "IL9", "MTOR", "IL13RA1", "IL12RB2", "IKBKB", "ELK3", "RPS6KA3", "PIK3CB", "IL15", "RPS6KA1", "CXCR1", "IL10RA", "IL11", "AKT1", "IL13", "FOXO3", "CDKN1A", "MYC", "NRAS", "STAT4", "IL2RB", "IL5", "IRS1", "ARAF", "PIK3CA", "AKT3", "PDPK1", "STAT5A", "RAF1", "SOS2", "SRF", "IL15RA", "MAPK3", "IL23A" ],
        "name" : "INTERLEUKIN SIGNALING PATHWAY%PANTHER PATHWAY%P00036",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176714,
        "selected" : false
      },
      "position" : {
        "x" : 471.2517372565933,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176711",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0871,
        "EnrichmentMap_Name" : "PID_NECTIN_PATHWAY%MSIGDB_C2%PID_NECTIN_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : -0.5491,
        "EnrichmentMap_GS_DESCR" : "PID_NECTIN_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_NECTIN_PATHWAY%MSIGDB_C2%PID_NECTIN_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0257,
        "EnrichmentMap_gs_size" : 24,
        "EnrichmentMap_NES_Data_Set_1_" : -1.5808,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9742999999999999,
        "EnrichmentMap_Genes" : [ "SRC", "RAC1", "TLN1", "FARP2", "F11R", "MLLT4", "CTNNA1", "ITGB3", "CLDN1", "RAP1A", "RAPGEF1", "CDC42", "DKFZP666O0110", "PTPRM", "NECTIN3", "NECTIN2", "PIK3R1", "ITGAV", "NECTIN1", "PIP5K1C", "CRK", "CTNNB1", "IQGAP1", "VAV2" ],
        "name" : "PID_NECTIN_PATHWAY%MSIGDB_C2%PID_NECTIN_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176711,
        "selected" : false
      },
      "position" : {
        "x" : 571.2517372565933,
        "y" : 436.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176708",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0328,
        "EnrichmentMap_Name" : "CADHERIN SIGNALING PATHWAY%PANTHER PATHWAY%P00012",
        "EnrichmentMap_ES_Data_Set_1_" : -0.3992,
        "EnrichmentMap_GS_DESCR" : "Cadherin signaling pathway",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "CADHERIN SIGNALING PATHWAY%PANTHER PATHWAY%P00012",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0083,
        "EnrichmentMap_gs_size" : 137,
        "EnrichmentMap_NES_Data_Set_1_" : -1.4891,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.9917,
        "EnrichmentMap_Genes" : [ "FZD2", "FZD4", "CDH6", "CDH2", "CDH5", "FZD5", "CTNND1", "CDH8", "ACTG2", "CDH4", "WNT6", "WNT11", "WNT10B", "WNT10A", "ACTC1", "WNT2B", "ACTB", "CDH3", "PCDH7", "WNT9B", "WNT9A", "ACTBL2", "ACTR2", "LEF1", "PCDHB1", "ACTA1", "CDH15", "PCDH9", "PCDHGC5", "PCDHGC4", "FER", "PCDH8", "PCDHGC3", "PCDHB15", "PCDHB14", "PCDHB13", "PCDHB12", "PCDHB11", "PCDHB10", "PCDHB16", "WNT7A", "PCDH11Y", "PTPN1", "CTNND2", "PCDH11X", "CDH9", "WNT16", "CELSR3", "CDH7", "PCDHAC2", "PCDHAC1", "PCDHA13", "CDH1", "PCDHA12", "PCDHA11", "PCDHA10", "CDH16", "PCDH10", "PCDH15", "PCDH12", "WNT8B", "PCDH19", "WNT8A", "PCDH18", "PCDHA1", "CELSR2", "CDH20", "CDH22", "CDH23", "PCDHA5", "CDH24", "PCDHA4", "PCDHA3", "PCDHA2", "PCDHA9", "PCDHA8", "PCDHA7", "PCDHA6", "PCDH20", "PCDHGA10", "PCDHGA11", "TCF7L1", "PCDHGA12", "PCDHB2", "FAT1", "PCDHB6", "FAT2", "PCDHB5", "FAT3", "FZD8", "DCHS1", "PCDHB4", "PCDHB3", "PCDHB8", "PCDHB7", "PCDHGB7", "PCDHGB6", "PCDHGB4", "PCDHGB2", "PCDHGA8", "PCDHGA7", "PCDHGA6", "PCDHGA5", "WNT7B", "PCDHGA3", "PCDHGA2", "FZD10", "PCDHGA1", "CDHR1", "CDH10", "CDHR2", "CDH12", "PCDHGB1", "CDH13", "CDH17", "CDH18", "CDH19", "PCDH1", "WNT2", "FZD6", "WNT5A", "CELSR1", "TCF7L2", "FZD7", "WNT3A", "FZD9", "ACTG1", "ACTA2", "CDH11", "WNT1", "FZD1", "WNT5B", "WNT3", "WNT4", "FZD3", "FSTL1", "CTNNB1" ],
        "name" : "CADHERIN SIGNALING PATHWAY%PANTHER PATHWAY%P00012",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176708,
        "selected" : false
      },
      "position" : {
        "x" : -528.7482627434067,
        "y" : 536.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176705",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0139,
        "EnrichmentMap_Name" : "GENERAL TRANSCRIPTION REGULATION%PANTHER PATHWAY%P00023",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6033,
        "EnrichmentMap_GS_DESCR" : "General transcription regulation",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "GENERAL TRANSCRIPTION REGULATION%PANTHER PATHWAY%P00023",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.003,
        "EnrichmentMap_gs_size" : 30,
        "EnrichmentMap_NES_Data_Set_1_" : 1.7455,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.997,
        "EnrichmentMap_Genes" : [ "GTF2A1", "GTF2B", "TAF9", "GTF2F1", "POLR2C", "GTF2A2", "TTF1", "POLR2F", "GTF2E1", "GTF2E2", "POLR2H", "TAF1C", "TAF9B", "CFAP20", "GTF2A1L", "BRF2", "BRF1", "TAF12", "MTERF2", "TAF11", "GTF2H1", "GTF2F2", "GTF2H4", "GTF2H3", "TAF8", "TBPL1", "TAF7", "TAF4", "TAF2", "TAF6" ],
        "name" : "GENERAL TRANSCRIPTION REGULATION%PANTHER PATHWAY%P00023",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176705,
        "selected" : false
      },
      "position" : {
        "x" : 304.6384865241714,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176702",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 1.0E-4,
        "EnrichmentMap_Name" : "PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7126,
        "EnrichmentMap_GS_DESCR" : "PID_FANCONI_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 42,
        "EnrichmentMap_NES_Data_Set_1_" : 2.1252,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "CHEK1", "HES1", "BRCA1", "HUS1", "NBN", "FANCD2", "BRCA2", "FBXW11", "ATM", "USP1", "BLM", "XRCC3", "UBE2T", "WDR48", "FAAP24", "RAD17", "RAD9A", "BRIP1", "ATRIP", "FANCM", "FANCL", "RMI1", "TOP3A", "RPA1", "RFC3", "FANCA", "MRE11A", "FANCB", "RFC2", "FANCE", "PALB2", "FANCG", "FANCF", "RAD50", "FAN1", "FANCC", "CENPS", "ATR", "TOPBP1", "RAD1", "RFC4", "H2AX" ],
        "name" : "PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176702,
        "selected" : false
      },
      "position" : {
        "x" : -331.76665721362156,
        "y" : -228.31609362590166
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176699",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "FOXM1 TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FOXM1 TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_ES_Data_Set_1_" : 0.7509,
        "EnrichmentMap_GS_DESCR" : "FOXM1 transcription factor network",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "FOXM1 TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FOXM1 TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 41,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2671,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "RB1", "CDK1", "PLK1", "CKS1B", "FOS", "ONECUT1", "CHEK2", "CENPA", "LAMA4", "CCNE1", "CCNB1", "CCNA2", "MAP2K1", "FOXM1", "CENPB", "H2BC1", "NFATC3", "BRCA2", "CDK4", "CDK2", "AURKB", "EP300", "SP1", "MMP2", "CCND1", "CENPF", "GSK3A", "CDKN2A", "MYC", "XRCC1", "HSPA1B", "GAS1", "SKP2", "ESR1", "ETV5", "CCNB2", "CREBBP", "TGFA", "CDC25B", "NEK2", "BIRC5" ],
        "name" : "FOXM1 TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FOXM1 TRANSCRIPTION FACTOR NETWORK",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176699,
        "selected" : false
      },
      "position" : {
        "x" : -3.7180083793930407,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176696",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "PID_E2F_PATHWAY%MSIGDB_C2%PID_E2F_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.6425,
        "EnrichmentMap_GS_DESCR" : "PID_E2F_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_E2F_PATHWAY%MSIGDB_C2%PID_E2F_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 63,
        "EnrichmentMap_NES_Data_Set_1_" : 2.0832,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "HEL126", "HIC1", "RB1", "CCNE2", "CES8", "DHFR", "CES3", "BRCA1", "RBBP4", "RBBP8", "E2F7", "RYBP", "ORC1L", "TRRAP", "SULT2A1", "CDC25A", "TYMS", "CCND3", "CEBPA", "E2F5", "SERPINE1", "WASF1", "CDK2", "RANBP1", "RRM2", "CDKN1B", "TRIM28", "CDKN2A", "UXT", "CDC6", "TOPBP1", "SIRT1", "MYBL2", "CCNE1", "CDC2", "CCNA2", "TFDP1", "RBL1", "TP73", "RBL2", "ATM", "EP300", "CES2", "HEL25", "SP1", "E2F2", "E2F3", "E2F4", "POLA1", "CES1", "CDKN1A", "RRM1", "MYC", "KAT2B", "TK1", "CDKN2C", "TFDP2", "HDAC1", "YY1", "MCL1", "KAT2A", "CREBBP", "APAF1" ],
        "name" : "PID_E2F_PATHWAY%MSIGDB_C2%PID_E2F_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176696,
        "selected" : false
      },
      "position" : {
        "x" : 201.62103428418118,
        "y" : -89.1573926829085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176693",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS",
        "EnrichmentMap_ES_Data_Set_1_" : 0.9083,
        "EnrichmentMap_GS_DESCR" : "Visual signal transduction: Rods",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 24,
        "EnrichmentMap_NES_Data_Set_1_" : 2.4544,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "PDE6G", "SLC24A1", "GUCY2D", "CNGA1", "GNAT1", "PDE6B", "CNGB1", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "RGS9", "GUCA1B", "RGS9BP", "GUCA1A", "RDH12", "RDH5", "SAG", "LRAT", "RHO", "PDE6A", "GNB1", "GNGT1", "GNB5" ],
        "name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176693,
        "selected" : false
      },
      "position" : {
        "x" : 224.56242289120632,
        "y" : -451.1737863444075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176690",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_Name" : "VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_ES_Data_Set_1_" : 0.8674,
        "EnrichmentMap_GS_DESCR" : "Visual signal transduction: Cones",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0,
        "EnrichmentMap_gs_size" : 23,
        "EnrichmentMap_NES_Data_Set_1_" : 2.2132,
        "EnrichmentMap_Colouring_Data_Set_1_" : 1.0,
        "EnrichmentMap_Genes" : [ "GUCY2D", "SLC24A2", "PDE6H", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "RGS9", "GNAT2", "GUCA1B", "RGS9BP", "GUCA1A", "RDH12", "GRK7", "PDE6C", "CNGB3", "GNB3", "RDH5", "CNGA3", "LRAT", "GNGT2", "GNB5", "ARR3" ],
        "name" : "VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176690,
        "selected" : false
      },
      "position" : {
        "x" : 311.8702002959915,
        "y" : -413.97684115397783
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176687",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0217,
        "EnrichmentMap_Name" : "VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM",
        "EnrichmentMap_ES_Data_Set_1_" : -0.619,
        "EnrichmentMap_GS_DESCR" : "VEGFR3 signaling in lymphatic endothelium",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.005,
        "EnrichmentMap_gs_size" : 25,
        "EnrichmentMap_NES_Data_Set_1_" : -1.8069,
        "EnrichmentMap_Colouring_Data_Set_1_" : -0.995,
        "EnrichmentMap_Genes" : [ "SOS1", "VEGFD", "SHC1", "ITGB1", "VEGFC", "FN1", "MAPK1", "MAPK11", "CREB1", "CRK", "ITGA1", "GRB2", "ITGA2", "RPS6KA1", "MAP2K4", "AKT1", "FLT4", "PIK3CA", "MAPK14", "ITGA4", "ITGA5", "PIK3R1", "COL1A1", "COL1A2", "MAPK3" ],
        "name" : "VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VEGFR3 SIGNALING IN LYMPHATIC ENDOTHELIUM",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176687,
        "selected" : false
      },
      "position" : {
        "x" : -428.7482627434067,
        "y" : 536.8641450978532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176684",
        "EnrichmentMap_fdr_qvalue_Data_Set_1_" : 0.0749,
        "EnrichmentMap_Name" : "PID_CASPASE_PATHWAY%MSIGDB_C2%PID_CASPASE_PATHWAY",
        "EnrichmentMap_ES_Data_Set_1_" : 0.5382,
        "EnrichmentMap_GS_DESCR" : "PID_CASPASE_PATHWAY",
        "EnrichmentMap_GS_Type" : "ENR",
        "shared_name" : "PID_CASPASE_PATHWAY%MSIGDB_C2%PID_CASPASE_PATHWAY",
        "EnrichmentMap_pvalue_Data_Set_1_" : 0.0214,
        "EnrichmentMap_gs_size" : 40,
        "EnrichmentMap_NES_Data_Set_1_" : 1.5812,
        "EnrichmentMap_Colouring_Data_Set_1_" : 0.9786,
        "EnrichmentMap_Genes" : [ "ARHGDIB", "APP", "CASP9", "CASP8", "CASP3", "CASP4", "CASP2", "DFFA", "RIPK1", "CYCS", "LIMK1", "BCL2", "HEL113", "PRF1", "CASP10", "BIRC3", "TNF", "SATB1", "MAP3K1", "CASP6", "CRADD", "MADD", "DIABLO", "LMNA", "TRAF2", "TRADD", "LMNB2", "CFL2", "DKFZP666O0110", "TFAP2A", "TNFRSF1A", "DFFB", "BAX", "GAS2", "PIDD1", "KRT18", "BIRC2", "PARP1", "ACTA1", "APAF1" ],
        "name" : "PID_CASPASE_PATHWAY%MSIGDB_C2%PID_CASPASE_PATHWAY",
        "EnrichmentMap_fwer_qvalue_Data_Set_1_" : 0.0,
        "SUID" : 176684,
        "selected" : false
      },
      "position" : {
        "x" : -423.4092200798325,
        "y" : 229.12479573261885
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "176969",
        "source" : "176909",
        "target" : "176918",
        "shared_name" : "ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_Overlap_size" : 16,
        "EnrichmentMap_similarity_coefficient" : 0.45893719806763283,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176969,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GNG3", "GNGT2", "GNG5", "GNG4", "GNG7", "GNB2", "GNB1", "GNB4", "GNB3", "GNG8", "GNAI3", "CACNA1B", "CACNA1A", "GNAI1", "GRM1", "GRM5" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176936",
        "source" : "176894",
        "target" : "176903",
        "shared_name" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY%MSIGDB_C2%PID_ECADHERIN_KERATINOCYTE_PATHWAY (Geneset_Overlap_Data Set 1) E-CADHERIN SIGNALING IN KERATINOCYTES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E-CADHERIN SIGNALING IN KERATINOCYTES",
        "EnrichmentMap_Overlap_size" : 15,
        "EnrichmentMap_similarity_coefficient" : 0.7672634271099744,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_ECADHERIN_KERATINOCYTE_PATHWAY%MSIGDB_C2%PID_ECADHERIN_KERATINOCYTE_PATHWAY (Geneset_Overlap_Data Set 1) E-CADHERIN SIGNALING IN KERATINOCYTES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E-CADHERIN SIGNALING IN KERATINOCYTES",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176936,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "EGFR", "PIP5K1A", "CASR", "CTNND1", "FMN1", "ZYX", "CTNNB1", "VASP", "SRC", "PIK3R1", "FYN", "JUP", "RAC1", "AJUBA", "CTNNA1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176981",
        "source" : "176885",
        "target" : "176906",
        "shared_name" : "PDGF SIGNALING PATHWAY%PANTHER PATHWAY%P00047 (Geneset_Overlap_Data Set 1) BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_Overlap_size" : 12,
        "EnrichmentMap_similarity_coefficient" : 0.3791348600508906,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PDGF SIGNALING PATHWAY%PANTHER PATHWAY%P00047 (Geneset_Overlap_Data Set 1) BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176981,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "MAP2K1", "RAF1", "SHC1", "JUN", "GRB2", "HRAS", "JAK3", "JAK1", "FOS", "SOS1", "MAPK3", "STAT3" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176993",
        "source" : "176882",
        "target" : "176867",
        "shared_name" : "BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS (Geneset_Overlap_Data Set 1) INTEGRIN SIGNALLING PATHWAY%PANTHER PATHWAY%P00034",
        "EnrichmentMap_Overlap_size" : 39,
        "EnrichmentMap_similarity_coefficient" : 0.3975487862922418,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS (Geneset_Overlap_Data Set 1) INTEGRIN SIGNALLING PATHWAY%PANTHER PATHWAY%P00034",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176993,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "COL5A2", "COL6A1", "COL4A3", "COL4A6", "COL6A3", "COL4A5", "ITGA3", "LAMA1", "LAMA3", "FN1", "LAMA2", "LAMB3", "ITGB1", "LAMB2", "LAMB1", "LAMA4", "LAMC1", "ITGA4", "ITGAV", "ITGA2", "ITGA1", "ITGA10", "ITGA11", "ITGA8", "ITGA7", "ITGA6", "ITGA5", "ITGA9", "LAMA5", "COL11A1", "COL11A2", "COL1A2", "COL1A1", "COL3A1", "COL2A1", "COL5A1", "COL4A1", "COL6A2", "COL4A4" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176954",
        "source" : "176870",
        "target" : "176882",
        "shared_name" : "PID_INTEGRIN1_PATHWAY%MSIGDB_C2%PID_INTEGRIN1_PATHWAY (Geneset_Overlap_Data Set 1) BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS",
        "EnrichmentMap_Overlap_size" : 47,
        "EnrichmentMap_similarity_coefficient" : 0.8251800720288115,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_INTEGRIN1_PATHWAY%MSIGDB_C2%PID_INTEGRIN1_PATHWAY (Geneset_Overlap_Data Set 1) BETA1 INTEGRIN CELL SURFACE INTERACTIONS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BETA1 INTEGRIN CELL SURFACE INTERACTIONS",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176954,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "COL4A4", "COL4A3", "COL4A6", "COL4A5", "SPP1", "NPNT", "NID1", "CSPG4", "COL2A1", "JAM2", "COL6A1", "PLAUR", "ITGAV", "COL11A2", "COL5A2", "FGA", "TGFBI", "VCAM1", "IGSF8", "CD81", "VEGFA", "THBS2", "ITGA4", "ITGA2", "ITGA1", "COL1A1", "VTN", "FBN1", "ITGA6", "COL18A1", "CD14", "LAMA5", "LAMA4", "LAMC2", "LAMC1", "F13A1", "LAMB3", "LAMB2", "LAMB1", "ITGB1", "COL3A1", "COL1A2", "LAMA1", "LAMA3", "THBS1", "MDK", "COL4A1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176930",
        "source" : "176864",
        "target" : "176696",
        "shared_name" : "E2F TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E2F TRANSCRIPTION FACTOR NETWORK (Geneset_Overlap_Data Set 1) PID_E2F_PATHWAY%MSIGDB_C2%PID_E2F_PATHWAY",
        "EnrichmentMap_Overlap_size" : 58,
        "EnrichmentMap_similarity_coefficient" : 0.827406067912397,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "E2F TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%E2F TRANSCRIPTION FACTOR NETWORK (Geneset_Overlap_Data Set 1) PID_E2F_PATHWAY%MSIGDB_C2%PID_E2F_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176930,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "RB1", "RBL2", "CDKN1B", "MCL1", "CDC6", "YY1", "E2F3", "RBBP8", "E2F2", "CCNA2", "CDKN1A", "SERPINE1", "UXT", "MYBL2", "SULT2A1", "TFDP2", "MYC", "CES3", "CES2", "CES1", "EP300", "TYMS", "E2F7", "RANBP1", "RRM1", "RRM2", "CDKN2C", "CCNE2", "DHFR", "POLA1", "RYBP", "KAT2B", "KAT2A", "RBL1", "TFDP1", "SIRT1", "TP73", "WASF1", "HDAC1", "RBBP4", "TRIM28", "E2F4", "E2F5", "BRCA1", "CCND3", "CREBBP", "TOPBP1", "APAF1", "SP1", "CEBPA", "TRRAP", "CDK2", "CCNE1", "HIC1", "ATM", "TK1", "CDC25A", "CDKN2A" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177020",
        "source" : "176852",
        "target" : "176690",
        "shared_name" : "PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_Overlap_size" : 10,
        "EnrichmentMap_similarity_coefficient" : 0.4015151515151515,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177020,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GNB5", "GUCY2D", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "RDH12", "RGS9BP", "RDH5", "LRAT" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176966",
        "source" : "176849",
        "target" : "176702",
        "shared_name" : "BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_Overlap_size" : 18,
        "EnrichmentMap_similarity_coefficient" : 0.6285714285714286,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176966,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "NBN", "ATM", "FANCA", "MRE11A", "HUS1", "FANCC", "FANCE", "FANCG", "FANCF", "BRCA1", "RAD50", "FANCD2", "RAD17", "RAD1", "BRCA2", "RAD9A", "CHEK1", "ATR" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176942",
        "source" : "176840",
        "target" : "176705",
        "shared_name" : "TRANSCRIPTION REGULATION BY BZIP TRANSCRIPTION FACTOR%PANTHER PATHWAY%P00055 (Geneset_Overlap_Data Set 1) GENERAL TRANSCRIPTION REGULATION%PANTHER PATHWAY%P00023",
        "EnrichmentMap_Overlap_size" : 30,
        "EnrichmentMap_similarity_coefficient" : 0.8191489361702128,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "TRANSCRIPTION REGULATION BY BZIP TRANSCRIPTION FACTOR%PANTHER PATHWAY%P00055 (Geneset_Overlap_Data Set 1) GENERAL TRANSCRIPTION REGULATION%PANTHER PATHWAY%P00023",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176942,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "POLR2F", "POLR2H", "TAF9B", "CFAP20", "GTF2A1L", "BRF2", "TAF12", "BRF1", "MTERF2", "TAF11", "GTF2H1", "GTF2F1", "GTF2H3", "GTF2F2", "GTF2H4", "TAF8", "TBPL1", "TAF7", "TAF6", "TAF4", "TAF2", "GTF2A1", "GTF2A2", "GTF2B", "TAF9", "TTF1", "GTF2E1", "GTF2E2", "TAF1C", "POLR2C" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177002",
        "source" : "176831",
        "target" : "176891",
        "shared_name" : "PID_ATM_PATHWAY%MSIGDB_C2%PID_ATM_PATHWAY (Geneset_Overlap_Data Set 1) ATM PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATM PATHWAY",
        "EnrichmentMap_Overlap_size" : 25,
        "EnrichmentMap_similarity_coefficient" : 0.7599818511796733,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_ATM_PATHWAY%MSIGDB_C2%PID_ATM_PATHWAY (Geneset_Overlap_Data Set 1) ATM PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATM PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177002,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "MDC1", "ABRAXAS1", "KAT5", "CDC25A", "RNF8", "SMC3", "UIMC1", "TP53BP1", "SMC1A", "TERF2", "RBBP8", "H2AX", "MDM2", "BLM", "CTBP1", "NBN", "ATM", "TOP3A", "BRCA1", "RAD50", "CHEK2", "FANCD2", "RAD17", "TRIM28", "RAD9A" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177017",
        "source" : "176816",
        "target" : "176861",
        "shared_name" : "BIOCARTA_INTEGRIN_PATHWAY%MSIGDB_C2%BIOCARTA_INTEGRIN_PATHWAY (Geneset_Overlap_Data Set 1) PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "EnrichmentMap_Overlap_size" : 16,
        "EnrichmentMap_similarity_coefficient" : 0.3878787878787879,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "BIOCARTA_INTEGRIN_PATHWAY%MSIGDB_C2%BIOCARTA_INTEGRIN_PATHWAY (Geneset_Overlap_Data Set 1) PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177017,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "JUN", "MAPK1", "ACTA1", "FYN", "RAP1A", "MAP2K1", "RAPGEF1", "TLN1", "MAPK8", "HEL114", "GRB2", "SOS1", "ARHA", "ITGB1", "RAF1", "ACTN1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177044",
        "source" : "176810",
        "target" : "176918",
        "shared_name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_Overlap_size" : 24,
        "EnrichmentMap_similarity_coefficient" : 0.4781704781704782,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177044,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "ADCY10", "PRKAR1B", "PRKAR1A", "GNB2", "GNB1", "GNB4", "GNB3", "GNB5", "GNAI3", "PRKX", "GNAI1", "GNAI2", "GNG10", "GNG3", "GNGT2", "GNG5", "PRKAR2B", "GNG4", "GNG7", "PRKAR2A", "PRKACG", "GNG8", "PRKACA", "PRKACB" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176957",
        "source" : "176810",
        "target" : "176909",
        "shared_name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043 (Geneset_Overlap_Data Set 1) ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730",
        "EnrichmentMap_Overlap_size" : 14,
        "EnrichmentMap_similarity_coefficient" : 0.4565217391304348,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "MUSCARINIC ACETYLCHOLINE RECEPTOR 2 AND 4 SIGNALING PATHWAY%PANTHER PATHWAY%P00043 (Geneset_Overlap_Data Set 1) ENDOGENOUS_CANNABINOID_SIGNALING%PANTHER PATHWAY%P05730",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176957,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GNB2", "GNB1", "GNB4", "GNB3", "GNAI3", "GNAI1", "GNG3", "GNGT2", "GNG5", "GNG4", "GNG7", "GNG8", "GNG11", "GNAO1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177038",
        "source" : "176807",
        "target" : "176918",
        "shared_name" : "PNAT%PANTHER PATHWAY%P05912 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_Overlap_size" : 23,
        "EnrichmentMap_similarity_coefficient" : 0.38773946360153255,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PNAT%PANTHER PATHWAY%P05912 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177038,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "PRKAR2A", "PRKACG", "GNG8", "PRKACA", "SNAP29", "PRKACB", "VAMP8", "GNB2", "GNB1", "GNB4", "GNB3", "VAMP1", "VAMP2", "VAMP3", "SNAP25", "SNAP23", "GNAI3", "PRKX", "GNAI1", "GNAI2", "GNG3", "PRKAR2B", "GNG4" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176984",
        "source" : "176804",
        "target" : "176849",
        "shared_name" : "BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_Overlap_size" : 12,
        "EnrichmentMap_similarity_coefficient" : 0.44787644787644787,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176984,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "BRCA1", "NBN", "FANCA", "FANCC", "FANCE", "FANCG", "FANCF", "RAD50", "RAD51", "FANCD2", "ATM", "ATR" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176972",
        "source" : "176801",
        "target" : "176876",
        "shared_name" : "PLK1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PLK1 SIGNALING EVENTS (Geneset_Overlap_Data Set 1) PID_PLK1_PATHWAY%MSIGDB_C2%PID_PLK1_PATHWAY",
        "EnrichmentMap_Overlap_size" : 30,
        "EnrichmentMap_similarity_coefficient" : 0.6428571428571428,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PLK1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PLK1 SIGNALING EVENTS (Geneset_Overlap_Data Set 1) PID_PLK1_PATHWAY%MSIGDB_C2%PID_PLK1_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176972,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "PAK1", "FZR1", "CCNB1", "PPP2R1A", "CLSPN", "FBXO5", "ECT2", "NINL", "CENPU", "NUDC", "FBXW11", "PLK1", "TUBG1", "CENPE", "WEE1", "PRC1", "GORASP1", "KIF20A", "KIZ", "SPC24", "ROCK2", "INCENP", "RAB1A", "ERCC6L", "BUB1B", "AURKA", "CDC14B", "PPP2CA", "GOLGA2", "CDC20" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176999",
        "source" : "176798",
        "target" : "176684",
        "shared_name" : "CASPASE CASCADE IN APOPTOSIS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CASPASE CASCADE IN APOPTOSIS (Geneset_Overlap_Data Set 1) PID_CASPASE_PATHWAY%MSIGDB_C2%PID_CASPASE_PATHWAY",
        "EnrichmentMap_Overlap_size" : 38,
        "EnrichmentMap_similarity_coefficient" : 0.8204545454545454,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "CASPASE CASCADE IN APOPTOSIS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%CASPASE CASCADE IN APOPTOSIS (Geneset_Overlap_Data Set 1) PID_CASPASE_PATHWAY%MSIGDB_C2%PID_CASPASE_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176999,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "PRF1", "PARP1", "CASP9", "CASP8", "CASP10", "CASP3", "RIPK1", "BIRC2", "TRADD", "MAP3K1", "CRADD", "TRAF2", "TNFRSF1A", "MADD", "CYCS", "BAX", "CASP6", "APP", "LMNB2", "BCL2", "PIDD1", "CFL2", "CASP4", "ARHGDIB", "LIMK1", "CASP2", "DFFB", "DFFA", "APAF1", "ACTA1", "GAS2", "BIRC3", "SATB1", "DIABLO", "LMNA", "TFAP2A", "KRT18", "TNF" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177035",
        "source" : "176792",
        "target" : "176849",
        "shared_name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_Overlap_size" : 17,
        "EnrichmentMap_similarity_coefficient" : 0.5714285714285714,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177035,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "RAD9A", "BRCA1", "BRCA2", "NBN", "CHEK1", "FANCA", "FANCC", "FANCE", "FANCG", "FANCF", "RAD50", "HUS1", "FANCD2", "ATM", "ATR", "RAD17", "RAD1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176978",
        "source" : "176792",
        "target" : "176702",
        "shared_name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_Overlap_size" : 41,
        "EnrichmentMap_similarity_coefficient" : 0.9151785714285714,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176978,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "CENPS", "RAD9A", "FBXW11", "HES1", "H2AX", "BLM", "WDR48", "BRCA1", "FAAP24", "BRCA2", "BRIP1", "NBN", "CHEK1", "TOPBP1", "USP1", "ATRIP", "FANCL", "FANCA", "RFC3", "FANCC", "RFC4", "FANCE", "FANCM", "FANCG", "RMI1", "FANCF", "RFC2", "RAD50", "XRCC3", "TOP3A", "RPA1", "HUS1", "FANCD2", "ATM", "FANCB", "PALB2", "ATR", "UBE2T", "RAD17", "RAD1", "FAN1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176927",
        "source" : "176792",
        "target" : "176915",
        "shared_name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "EnrichmentMap_Overlap_size" : 19,
        "EnrichmentMap_similarity_coefficient" : 0.385380788365863,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "FANCONI ANEMIA PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FANCONI ANEMIA PATHWAY (Geneset_Overlap_Data Set 1) ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176927,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "RAD9A", "BTRC", "FBXW11", "BRCA2", "NBN", "CHEK1", "TOPBP1", "ATRIP", "RFC5", "RFC3", "RFC4", "RFC2", "RPA1", "HUS1", "FANCD2", "RPA2", "ATR", "RAD17", "RAD1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177005",
        "source" : "176789",
        "target" : "176822",
        "shared_name" : "ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING (Geneset_Overlap_Data Set 1) PID_ANGIOPOIETIN_RECEPTOR_PATHWAY%MSIGDB_C2%PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "EnrichmentMap_Overlap_size" : 36,
        "EnrichmentMap_similarity_coefficient" : 0.819838056680162,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ANGIOPOIETIN RECEPTOR TIE2-MEDIATED SIGNALING (Geneset_Overlap_Data Set 1) PID_ANGIOPOIETIN_RECEPTOR_PATHWAY%MSIGDB_C2%PID_ANGIOPOIETIN_RECEPTOR_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177005,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "NFKB1", "ITGB1", "CDKN1A", "MAPK8", "MAPK1", "RAC1", "MAPK3", "MMP2", "PAK1", "FYN", "STAT5B", "PLD2", "MAPK14", "GRB7", "RPS6KB1", "FES", "SHC1", "PXN", "FOXO1", "NCK1", "PTPN11", "GRB2", "CRK", "AGTR1", "FGF2", "GRB14", "F2", "ELF2", "PLG", "ANGPT1", "PIK3R1", "ANGPT4", "ANGPT2", "TNF", "BMX", "RELA" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177014",
        "source" : "176786",
        "target" : "176861",
        "shared_name" : "SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE (Geneset_Overlap_Data Set 1) PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "EnrichmentMap_Overlap_size" : 46,
        "EnrichmentMap_similarity_coefficient" : 0.8016826923076923,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%SIGNALING EVENTS MEDIATED BY FOCAL ADHESION KINASE (Geneset_Overlap_Data Set 1) PID_FAK_PATHWAY%MSIGDB_C2%PID_FAK_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177014,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "CCND1", "JUN", "BRAF", "PTPN21", "NCK2", "SH3GL1", "ARHGEF11", "MAPK9", "RRAS", "ARHGEF28", "ASAP1", "GIT2", "ARHGAP26", "KLF8", "ACTN1", "ITGB1", "ROCK2", "MAPK8", "ITGB5", "MAPK1", "ITGAV", "RAC1", "RAPGEF1", "MAP2K4", "PAK1", "WASL", "FYN", "YES1", "ELMO1", "DOCK1", "GRB7", "SRC", "PXN", "RAP1A", "NCK1", "ARHGAP35", "MAP2K1", "GRB2", "SOS1", "MAPK8IP3", "CRK", "ACTA1", "RAF1", "TLN1", "PIK3R1", "BMX" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177026",
        "source" : "176777",
        "target" : "176906",
        "shared_name" : "IL6%NETPATH%IL6 (Geneset_Overlap_Data Set 1) BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "EnrichmentMap_Overlap_size" : 12,
        "EnrichmentMap_similarity_coefficient" : 0.4270833333333333,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "IL6%NETPATH%IL6 (Geneset_Overlap_Data Set 1) BIOCARTA_IL6_PATHWAY%MSIGDB_C2%BIOCARTA_IL6_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177026,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "IL6R", "JAK1", "MAP2K1", "FOS", "IL6ST", "SHC1", "MAPK3", "JUN", "STAT3", "PTPN11", "IL6", "GRB2" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177008",
        "source" : "176765",
        "target" : "176900",
        "shared_name" : "TNFALPHA%NETPATH%TNFALPHA (Geneset_Overlap_Data Set 1) TNFALPHA%IOB%TNFALPHA",
        "EnrichmentMap_Overlap_size" : 147,
        "EnrichmentMap_similarity_coefficient" : 0.8183290155440415,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "TNFALPHA%NETPATH%TNFALPHA (Geneset_Overlap_Data Set 1) TNFALPHA%IOB%TNFALPHA",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177008,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "DOK1", "TXLNA", "CDC34", "FANCD2", "CDC37", "MAPKAPK2", "TRIB3", "NUPR1", "FKBP5", "NSMAF", "COPB2", "PSMD12", "PSMD13", "KIAA0287", "TNFRSF11A", "GLG1", "BAG4", "BRINP1", "G3BP2", "FADD", "MAP2K5", "MAP2K6", "CREBBP", "JUN", "UBE2I", "CRADD", "SEC16A", "DKFZP781N011", "DKFZP566E044", "MCC", "NFKB1", "SMARCA4", "CDK9", "NFKBIA", "REL", "ALPL", "TAB3", "NFKBIE", "MAP3K11", "DDX3X", "HSP90AB1", "MCM7", "FAF1", "IKBKAP", "PPP6C", "YWHAQ", "BCL7A", "SUMO1", "PPP1R13L", "NKIRAS1", "CASP10", "NKIRAS2", "CASP3", "NFKBIZ", "CASP2", "HEL-S-1", "IKBKG", "IKBKE", "YWHAG", "HEL-S-102", "RIPK3", "ACTL6A", "COMMD1", "TNFRSF1B", "YWHAZ", "CREB1", "RASA3", "TRAF4", "MUXA", "POLR1A", "TRAF6", "TRAF5", "POLR1C", "POLR1D", "MCM5", "PFDN2", "BIRC2", "HDAC2", "HDAC1", "SRC", "AKAP8", "MTIF2", "NR2C2", "TANK", "EGFR", "RELB", "MAPK9", "MAPK8", "TIFA", "FLNA", "MAPK1", "POLR2H", "POLR2L", "MAPK3", "MAP3K2", "SMARCE1", "RNF25", "STAT1", "PTPN11", "MAPK14", "LRPPRC", "PML", "KTN1", "MAP3K7IP1", "TNIP2", "PRC1", "PSMC1", "PDCD2", "TBKBP1", "PKN1", "RB1", "RPL4", "RPL30", "HEL2", "UBE2D2", "UBE2D3", "ZFAND5", "RPL8", "TNF", "DCAF7", "RPL6", "FBL", "PSMD6", "TBK1", "PSMD7", "RPS6KA5", "PSMD2", "PSMD3", "PAPOLA", "KPNA6", "DPF2", "PSMD1", "TNFRSF8", "MAP3K8", "KPNA2", "RPS11", "KPNA3", "RPS13", "GTF2I", "SKP1", "SMARCC1", "SMARCC2", "CSNK2A1", "FBXW11", "FBXW7", "USP2", "TRPC4AP" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177047",
        "source" : "176759",
        "target" : "176849",
        "shared_name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "EnrichmentMap_Overlap_size" : 13,
        "EnrichmentMap_similarity_coefficient" : 0.5007002801120448,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) BIOCARTA_ATRBRCA_PATHWAY%MSIGDB_C2%BIOCARTA_ATRBRCA_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177047,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "RAD51", "NBN", "ATM", "FANCA", "MRE11A", "FANCC", "FANCE", "FANCG", "FANCF", "BRCA1", "RAD50", "FANCD2", "ATR" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176990",
        "source" : "176759",
        "target" : "176804",
        "shared_name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS",
        "EnrichmentMap_Overlap_size" : 25,
        "EnrichmentMap_similarity_coefficient" : 0.9118037135278514,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) BARD1 SIGNALING EVENTS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%BARD1 SIGNALING EVENTS",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176990,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "XRCC5", "UBE2L3", "UBE2D3", "CSTF1", "CCNE1", "BARD1", "EWSR1", "RBBP8", "RAD51", "NBN", "FANCL", "CDK2", "ATM", "FANCA", "FANCC", "PRKDC", "FANCE", "FANCG", "FANCF", "BRCA1", "RAD50", "FANCD2", "PCNA", "TOPBP1", "ATR" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176921",
        "source" : "176759",
        "target" : "176702",
        "shared_name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "EnrichmentMap_Overlap_size" : 14,
        "EnrichmentMap_similarity_coefficient" : 0.3988603988603988,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_BARD1_PATHWAY%MSIGDB_C2%PID_BARD1_PATHWAY (Geneset_Overlap_Data Set 1) PID_FANCONI_PATHWAY%MSIGDB_C2%PID_FANCONI_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176921,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "NBN", "FANCL", "ATM", "FANCA", "MRE11A", "FANCC", "FANCE", "FANCG", "FANCF", "BRCA1", "RAD50", "FANCD2", "TOPBP1", "ATR" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176948",
        "source" : "176756",
        "target" : "176912",
        "shared_name" : "PID_INSULIN_PATHWAY%MSIGDB_C2%PID_INSULIN_PATHWAY (Geneset_Overlap_Data Set 1) INSULIN PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%INSULIN PATHWAY",
        "EnrichmentMap_Overlap_size" : 34,
        "EnrichmentMap_similarity_coefficient" : 0.7943071965628357,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_INSULIN_PATHWAY%MSIGDB_C2%PID_INSULIN_PATHWAY (Geneset_Overlap_Data Set 1) INSULIN PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%INSULIN PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176948,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "INS", "SGK1", "GRB10", "SHC1", "PIK3R1", "EXOC4", "PRKCZ", "PARD6A", "EXOC6", "NCK1", "INSR", "EXOC5", "PTPN1", "EXOC2", "EXOC1", "RAPGEF1", "TRIP10", "PTPN11", "CBL", "PRKCI", "PDPK1", "CRK", "GRB14", "RPS6KB1", "F2RL2", "NCK2", "HRAS", "GRB2", "SOS1", "DOK1", "SH2B2", "PTPRA", "IRS1", "EIF4EBP1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177032",
        "source" : "176744",
        "target" : "176915",
        "shared_name" : "PID_ATR_PATHWAY%MSIGDB_C2%PID_ATR_PATHWAY (Geneset_Overlap_Data Set 1) ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "EnrichmentMap_Overlap_size" : 33,
        "EnrichmentMap_similarity_coefficient" : 0.8977941176470587,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_ATR_PATHWAY%MSIGDB_C2%PID_ATR_PATHWAY (Geneset_Overlap_Data Set 1) ATR SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%ATR SIGNALING PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177032,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "CDC25A", "CCNA2", "PPP2R1A", "SMARCAL1", "CEP164", "PPP2R2B", "PPP2CA", "MDM2", "BRCA2", "RAD51", "CHEK1", "NBN", "ATRIP", "RFC3", "RFC4", "CDC6", "FBXW11", "RFC2", "CDK2", "TIMELESS", "RPA1", "HUS1", "PLK1", "CLSPN", "YWHAZ", "FANCD2", "RAD17", "MCM7", "RAD1", "TOPBP1", "RAD9A", "ATR", "MCM2" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176924",
        "source" : "176741",
        "target" : "176828",
        "shared_name" : "PID_MYC_ACTIV_PATHWAY%MSIGDB_C2%PID_MYC_ACTIV_PATHWAY (Geneset_Overlap_Data Set 1) VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION",
        "EnrichmentMap_Overlap_size" : 63,
        "EnrichmentMap_similarity_coefficient" : 0.8271099744245525,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_MYC_ACTIV_PATHWAY%MSIGDB_C2%PID_MYC_ACTIV_PATHWAY (Geneset_Overlap_Data Set 1) VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VALIDATED TARGETS OF C-MYC TRANSCRIPTIONAL ACTIVATION",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176924,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "SUPT7L", "KAT5", "CDC25A", "RUVBL2", "RUVBL1", "MMP9", "KAT2A", "BAX", "E2F3", "EIF2S1", "CREBBP", "NBN", "NCL", "BIRC5", "EIF4A1", "BMI1", "PEG10", "UBTF", "CCNB1", "PIM1", "RCC1", "PMAIP1", "CAD", "NME2", "BCAT1", "SHMT1", "ID2", "RPL11", "HMGA1", "MAX", "IREB2", "CDCA7", "HSPD1", "MYC", "MTDH", "PRDX3", "MYCT1", "PDCD10", "EIF4E", "HSPA4", "HUWE1", "CCND2", "KIR3DL1", "FOSL1", "TERT", "LIN28B", "GPAM", "POLR3D", "NDUFAF2", "SNAI1", "TAF4B", "SERPINI1", "SMAD4", "PFKM", "EIF4G1", "TRRAP", "CDK4", "EP300", "TAF9", "TAF12", "TK1", "TAF10", "ACTL6A" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176945",
        "source" : "176738",
        "target" : "176837",
        "shared_name" : "PDGFR-ALPHA SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PDGFR-ALPHA SIGNALING PATHWAY (Geneset_Overlap_Data Set 1) PID_PDGFRA_PATHWAY%MSIGDB_C2%PID_PDGFRA_PATHWAY",
        "EnrichmentMap_Overlap_size" : 15,
        "EnrichmentMap_similarity_coefficient" : 0.7672634271099744,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PDGFR-ALPHA SIGNALING PATHWAY%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%PDGFR-ALPHA SIGNALING PATHWAY (Geneset_Overlap_Data Set 1) PID_PDGFRA_PATHWAY%MSIGDB_C2%PID_PDGFRA_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176945,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "PDGFRA", "GRB2", "SOS1", "CRK", "ITGAV", "CRKL", "RAPGEF1", "JAK1", "CAV3", "CSNK2A1", "JUN", "SHC1", "SHB", "FOS", "PIK3R1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177041",
        "source" : "176735",
        "target" : "176768",
        "shared_name" : "PID_AURORA_A_PATHWAY%MSIGDB_C2%PID_AURORA_A_PATHWAY (Geneset_Overlap_Data Set 1) AURORA A SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA A SIGNALING",
        "EnrichmentMap_Overlap_size" : 21,
        "EnrichmentMap_similarity_coefficient" : 0.72,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_AURORA_A_PATHWAY%MSIGDB_C2%PID_AURORA_A_PATHWAY (Geneset_Overlap_Data Set 1) AURORA A SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA A SIGNALING",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177041,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GADD45A", "PAK1", "NFKBIA", "MDM2", "NDEL1", "CENPA", "AURKB", "AURKA", "BRCA1", "OAZ1", "FZR1", "DLGAP5", "TDRD7", "PPP2R5D", "CKAP5", "GSK3B", "TACC3", "AURKAIP1", "AJUBA", "BIRC5", "RAN" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176963",
        "source" : "176732",
        "target" : "176774",
        "shared_name" : "ALPHA6BETA4INTEGRIN%IOB%ALPHA6BETA4INTEGRIN (Geneset_Overlap_Data Set 1) ALPHA6BETA4INTEGRIN%NETPATH%ALPHA6BETA4INTEGRIN",
        "EnrichmentMap_Overlap_size" : 53,
        "EnrichmentMap_similarity_coefficient" : 0.9568965517241379,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "ALPHA6BETA4INTEGRIN%IOB%ALPHA6BETA4INTEGRIN (Geneset_Overlap_Data Set 1) ALPHA6BETA4INTEGRIN%NETPATH%ALPHA6BETA4INTEGRIN",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176963,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "HEL2", "RTKN", "IRS1", "ITGB4", "HEL113", "PIK3CD", "LAMC2", "LAMC1", "MYLK3", "YWHAQ", "CASP3", "HEL-S-1", "RAC1", "EPHB2", "DST", "RPSA", "PRKCA", "YWHAZ", "ITGA6", "MET", "PLEC", "COL17A1", "LAMA5", "CD151", "SHC1", "SRC", "LAMA3", "PIK3R3", "PIK3R2", "PIK3R1", "NTN1", "EGFR", "PAK1", "ERBB2", "EIF4EBP1", "CLCA1", "FYN", "SFN", "EIF4E", "SMAD2", "YES1", "LAMB3", "LAMB2", "BAD", "DKFZP666O0110", "ERBIN", "LAMB1", "PTPN11", "MTOR", "EIF6", "ARHA", "GRB2", "TP73" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177023",
        "source" : "176729",
        "target" : "176918",
        "shared_name" : "IONOTROPIC GLUTAMATE RECEPTOR PATHWAY%PANTHER PATHWAY%P00037 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "EnrichmentMap_Overlap_size" : 27,
        "EnrichmentMap_similarity_coefficient" : 0.5706457925636008,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "IONOTROPIC GLUTAMATE RECEPTOR PATHWAY%PANTHER PATHWAY%P00037 (Geneset_Overlap_Data Set 1) METABOTROPIC GLUTAMATE RECEPTOR GROUP III PATHWAY%PANTHER PATHWAY%P00039",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177023,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GRIN3A", "VAMP1", "VAMP2", "VAMP3", "GRIA1", "GRIA2", "SNAP25", "GRIK5", "SNAP23", "SLC1A1", "SLC1A2", "GRIK3", "SLC1A3", "GRIK4", "GRIK1", "GRIK2", "SLC1A6", "SLC1A7", "GRIN2A", "SNAP29", "GRIA3", "GRIA4", "GRIN2C", "GRIN2B", "GRIN2D", "GRIN1", "VAMP8" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176939",
        "source" : "176726",
        "target" : "176825",
        "shared_name" : "PID_AURORA_B_PATHWAY%MSIGDB_C2%PID_AURORA_B_PATHWAY (Geneset_Overlap_Data Set 1) AURORA B SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA B SIGNALING",
        "EnrichmentMap_Overlap_size" : 20,
        "EnrichmentMap_similarity_coefficient" : 0.5654761904761905,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_AURORA_B_PATHWAY%MSIGDB_C2%PID_AURORA_B_PATHWAY (Geneset_Overlap_Data Set 1) AURORA B SIGNALING%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%AURORA B SIGNALING",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176939,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "CDCA8", "NCAPG", "KLHL13", "AURKC", "SMC4", "CENPA", "AURKB", "MYLK", "SMC2", "AURKA", "PPP1CC", "SEPTIN1", "NSUN2", "KIF23", "PPP2R5D", "KLHL9", "INCENP", "NCL", "BIRC5", "KIF20A" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177011",
        "source" : "176720",
        "target" : "176690",
        "shared_name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_Overlap_size" : 20,
        "EnrichmentMap_similarity_coefficient" : 0.8928571428571428,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177011,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GNB5", "SLC24A2", "GUCY2D", "PDE6H", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "GNGT2", "RDH12", "GNAT2", "RGS9BP", "GRK7", "PDE6C", "ARR3", "RDH5", "CNGB3", "GNB3", "CNGA3", "LRAT" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176960",
        "source" : "176720",
        "target" : "176852",
        "shared_name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY (Geneset_Overlap_Data Set 1) PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_Overlap_size" : 11,
        "EnrichmentMap_similarity_coefficient" : 0.45833333333333337,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY (Geneset_Overlap_Data Set 1) PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176960,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GNB5", "GUCY2D", "DKFZP686E1183", "GUCA1C", "GUCY2F", "RPE65", "GRK1", "RDH12", "RGS9BP", "RDH5", "LRAT" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176933",
        "source" : "176717",
        "target" : "176807",
        "shared_name" : "NICOTINE PHARMACODYNAMICS PATHWAY%PANTHER PATHWAY%P06587 (Geneset_Overlap_Data Set 1) PNAT%PANTHER PATHWAY%P05912",
        "EnrichmentMap_Overlap_size" : 16,
        "EnrichmentMap_similarity_coefficient" : 0.45314685314685316,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "NICOTINE PHARMACODYNAMICS PATHWAY%PANTHER PATHWAY%P06587 (Geneset_Overlap_Data Set 1) PNAT%PANTHER PATHWAY%P05912",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176933,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "CLIC6", "KCNK9", "EPB41", "ADCY2", "GNAI1", "EPB41L1", "EPB41L2", "FLNA", "DRD2", "PRKACA", "DRD4", "SLC18A2", "PPP1CA", "GNB1", "PPP1R1B", "KCNK3" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176975",
        "source" : "176699",
        "target" : "176888",
        "shared_name" : "FOXM1 TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FOXM1 TRANSCRIPTION FACTOR NETWORK (Geneset_Overlap_Data Set 1) PID_FOXM1_PATHWAY%MSIGDB_C2%PID_FOXM1_PATHWAY",
        "EnrichmentMap_Overlap_size" : 36,
        "EnrichmentMap_similarity_coefficient" : 0.8922888616891065,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "FOXM1 TRANSCRIPTION FACTOR NETWORK%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%FOXM1 TRANSCRIPTION FACTOR NETWORK (Geneset_Overlap_Data Set 1) PID_FOXM1_PATHWAY%MSIGDB_C2%PID_FOXM1_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176975,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GAS1", "CCNB1", "RB1", "CCND1", "CCNB2", "PLK1", "NFATC3", "GSK3A", "FOS", "ETV5", "LAMA4", "CCNA2", "ONECUT1", "TGFA", "CREBBP", "FOXM1", "AURKB", "BRCA2", "CENPB", "MAP2K1", "CENPA", "CKS1B", "NEK2", "H2BC1", "CENPF", "MYC", "SP1", "CDK4", "CDK2", "EP300", "MMP2", "CCNE1", "CHEK2", "BIRC5", "SKP2", "CDKN2A" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177029",
        "source" : "176693",
        "target" : "176720",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY",
        "EnrichmentMap_Overlap_size" : 10,
        "EnrichmentMap_similarity_coefficient" : 0.38095238095238093,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) PID_CONE_PATHWAY%MSIGDB_C2%PID_CONE_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 177029,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GUCY2F", "RPE65", "GRK1", "RDH12", "RGS9BP", "RDH5", "LRAT", "GNB5", "GUCY2D", "GUCA1C" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176996",
        "source" : "176693",
        "target" : "176834",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) HETEROTRIMERIC G-PROTEIN SIGNALING PATHWAY-ROD OUTER SEGMENT PHOTOTRANSDUCTION%PANTHER PATHWAY%P00028",
        "EnrichmentMap_Overlap_size" : 12,
        "EnrichmentMap_similarity_coefficient" : 0.39285714285714285,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) HETEROTRIMERIC G-PROTEIN SIGNALING PATHWAY-ROD OUTER SEGMENT PHOTOTRANSDUCTION%PANTHER PATHWAY%P00028",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176996,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "PDE6B", "GNAT1", "PDE6A", "GRK1", "CNGB1", "GNB1", "GNB5", "RGS9", "PDE6G", "GNGT1", "RHO", "CNGA1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176987",
        "source" : "176693",
        "target" : "176852",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "EnrichmentMap_Overlap_size" : 19,
        "EnrichmentMap_similarity_coefficient" : 0.855,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) PID_RHODOPSIN_PATHWAY%MSIGDB_C2%PID_RHODOPSIN_PATHWAY",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176987,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GUCY2F", "GNAT1", "RPE65", "PDE6A", "GRK1", "RDH12", "RGS9BP", "GNB1", "RDH5", "LRAT", "GNB5", "SLC24A1", "GUCY2D", "PDE6G", "GNGT1", "RHO", "SAG", "GUCA1C", "CNGA1" ]
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176951",
        "source" : "176693",
        "target" : "176690",
        "shared_name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "EnrichmentMap_Overlap_size" : 13,
        "EnrichmentMap_similarity_coefficient" : 0.4737851662404092,
        "shared_interaction" : "Geneset_Overlap",
        "EnrichmentMap_Data_Set" : "Data Set 1",
        "name" : "VISUAL SIGNAL TRANSDUCTION: RODS%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: RODS (Geneset_Overlap_Data Set 1) VISUAL SIGNAL TRANSDUCTION: CONES%PATHWAY INTERACTION DATABASE NCI-NATURE CURATED DATA%VISUAL SIGNAL TRANSDUCTION: CONES",
        "interaction" : "Geneset_Overlap",
        "SUID" : 176951,
        "selected" : false,
        "EnrichmentMap_Overlap_genes" : [ "GUCY2F", "RPE65", "GRK1", "RDH12", "RGS9BP", "RDH5", "LRAT", "GNB5", "RGS9", "GUCY2D", "GUCA1B", "GUCA1A", "GUCA1C" ]
      },
      "selected" : false
    } ]
  }
}}